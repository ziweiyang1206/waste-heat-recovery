# -*- coding: utf-8 -*-
"""
run_all.py — 一键按序重跑整篇论文的统计脚本（可复现入口）。

执行顺序（严格依赖，07/08/09/10 依赖 05 输出，务必 05 最先）：
    05_gini_theil_calc.py   -> Gini/Theil 三层框架（核心，输出 ../碳不平等测算_Gini_Theil.xlsx）
    07_DCEA.py              -> DCEA 浓度指数 + 减排成本
    08_compensation.py      -> 跨区域补偿机制
    09_sensitivity.py       -> Monte Carlo 敏感性（正文 Fig.8）
    10_robust_inequality.py -> CV/RMD/Atkinson 稳健指标（Table 1）

用法：
    python run_all.py            # 全跑
    python run_all.py 07 09      # 只跑指定的几个（须自带 05 已跑过）
    python run_all.py --check    # 只做结果核验（读现有 xlsx 打印验证锚点，不重跑）

说明：
    - 脚本本身已写好绝对路径，指向当前投稿数据目录；本入口只需保证运行环境有 python 及依赖。
    - 09 为确定性（固定种子 rng(42)），重跑结果完全一致。
    - 跑完打印"验证锚点"：2035 Gini/缓解/组间贡献、人均净福利、补偿池、敏感性判定，用于自证可复现。
"""
import os
import sys
import time
import subprocess

# ---------- 路径与脚本清单 ----------
HERE = os.path.dirname(os.path.abspath(__file__))           # 实验过程/
CORE = os.path.join(HERE, "05_gini_theil_calc.py")
SCRIPTS = [  # 按依赖顺序
    ("05_gini_theil_calc",   "05_gini_theil_calc.py"),
    ("07_DCEA",              "07_DCEA.py"),
    ("08_compensation",      "08_compensation.py"),
    ("09_sensitivity",       "09_sensitivity.py"),
    ("10_robust_inequality", "10_robust_inequality.py"),
]
PY = sys.executable


def run_one(name, rel):
    t0 = time.time()
    script = os.path.join(HERE, rel)
    try:
        r = subprocess.run([PY, script], capture_output=True, text=True,
                           cwd=HERE, encoding="utf-8", errors="replace")
        ok = r.returncode == 0
        tail = (r.stdout or "")[-600:] if ok else (r.stderr or "")[-800:]
        return name, ok, time.time() - t0, tail
    except Exception as e:  # noqa
        return name, False, time.time() - t0, str(e)


def check_anchors():
    """只读现有 xlsx 打印论文核心数字（验证锚点），不重跑。"""
    print("\n" + "=" * 70)
    print("验证锚点（应与此处数字一致，勿改口径）")
    print("=" * 70)
    try:
        import pandas as pd
        gini = os.path.join(os.path.dirname(HERE), "碳不平等测算_Gini_Theil.xlsx")
        df = pd.read_excel(gini, sheet_name="Gini_Theil指数")
        r = df[(df["情景"] == "TAS算力转移") & (df["年份"] == 2035)].iloc[0]
        print(f"  2035 TAS: Gini(负担)={r['Gini_人均碳负担(无余热)']:.4f} | "
              f"Gini(净,非负化)={r['Gini_人均净负担_非负化(方案2)']:.4f} | "
              f"缓解={r['缓解效应_非负化(%)']:+.2f}% | 组间贡献={r['组间贡献率(%)']:.1f}%")
        print("  论文锚点: 0.904 / 0.934 / −3.32% / 60.5%")
        return True
    except Exception as e:  # noqa
        print("  核验失败（需先跑 05）:", e)
        return False


def main():
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    if "--check" in sys.argv:
        check_anchors()
        return

    targets = args if args else [n for n, _ in SCRIPTS]
    order = {n: i for i, (n, _) in enumerate(SCRIPTS)}
    targets = sorted(targets, key=lambda n: order.get(n, 99))
    unknown = [t for t in targets if t not in order]
    if unknown:
        print("未知脚本名:", unknown, "（可选：", [n for n, _ in SCRIPTS], "）")
        return

    print(f"Python: {PY}")
    print(f"工作目录: {HERE}")
    print("待运行:", " -> ".join(targets))
    results = []
    for name in targets:
        rel = dict(SCRIPTS)[name]
        print(f"\n>>> 运行 {name} ...")
        res = run_one(name, rel)
        results.append(res)
        status = "OK" if res[1] else "FAIL"
        print(f"<<< {name}: {status}  ({res[2]:.1f}s)")
        if not res[1]:
            print("   错误尾部:\n" + ("    " + res[3].replace("\n", "\n    ") if res[3] else "    (无输出)"))

    print("\n" + "=" * 70)
    print("汇总")
    print("=" * 70)
    all_ok = True
    for name, ok, dt, _ in results:
        print(f"  [{'OK  ' if ok else 'FAIL'}] {name:<26} {dt:5.1f}s")
        all_ok &= ok
    if all_ok:
        print("全部成功。")
        check_anchors()
    else:
        print("存在失败脚本——检查上方错误尾部；05 失败时 07/08/09/10 结果不可用。")


if __name__ == "__main__":
    main()

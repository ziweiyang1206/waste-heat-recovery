# -*- coding: utf-8 -*-
"""
06_visualization.py  (English, Arial 12pt)
Reads 05_Gini_Theil output, generates 6 publication-quality figures.
Legend labels kept short; parentheses removed.
"""

import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib as mpl

# ============================ Global style (Arial 12pt) ============================
mpl.rcParams['font.family'] = 'Arial'
mpl.rcParams['font.size'] = 12
mpl.rcParams['axes.linewidth'] = 1.0
mpl.rcParams['figure.dpi'] = 100
mpl.rcParams['savefig.dpi'] = 300
mpl.rcParams['savefig.bbox'] = 'tight'
mpl.rcParams['mathtext.fontset'] = 'custom'
mpl.rcParams['mathtext.rm'] = 'Arial'
mpl.rcParams['mathtext.it'] = 'Arial:italic'
mpl.rcParams['mathtext.bf'] = 'Arial:bold'

# ============================ Colors (centralized) ============================
COLOR = {
    'coal': '#E74C3C', 'coal_light': '#F5B7B1',
    'clean': '#3498DB', 'clean_light': '#AED6F1',
    'no_wh': '#2C3E50', 'wh': '#E67E22', 'wh_light': '#F8C471',
    'source': '#2980B9', 'recv': '#E67E22',
    'diag': '#7F8C8D',
}

CN2EN = {'成都':'Chengdu','重庆':'Chongqing','贵阳':'Guiyang','韶关':'Shaoguan',
         '芜湖':'Wuhu','呼和浩特':'Hohhot','庆阳':'Qingyang','张家口':'Zhangjiakou',
         '中卫':'Zhongwei','北京':'Beijing','上海':'Shanghai','广州':'Guangzhou','深圳':'Shenzhen'}

GROUP_COAL = ['呼和浩特','张家口','芜湖','庆阳','中卫']
GROUP_CLEAN = ['成都','重庆','贵阳','韶关']
C9 = GROUP_COAL + GROUP_CLEAN
SRC4 = ['北京','上海','广州','深圳']

def city_color(c):
    if c in GROUP_COAL: return COLOR['coal']
    if c in GROUP_CLEAN: return COLOR['clean']
    if c in SRC4: return COLOR['source']
    return '#999999'

def en(c): return CN2EN.get(c, c)

# ============================ Paths ============================
BASE = r"D:\杨紫薇\第五篇-算力转移导致的水能碳足迹流动\投稿\数据、代码及图源文件"
GINI_XLSX = BASE + r"\碳不平等测算_Gini_Theil.xlsx"
OUT_DIR = BASE + r"\实验过程"
os.makedirs(OUT_DIR, exist_ok=True)

# ============================ Read data ============================
df_city = pd.read_excel(GINI_XLSX, sheet_name="9城碳负担与人均GDP")
df_gini = pd.read_excel(GINI_XLSX, sheet_name="Gini_Theil指数")
df_13 = pd.read_excel(GINI_XLSX, sheet_name="13城净负担_TAS")
print("Data loaded:", df_city.shape, df_gini.shape, df_13.shape)

# ======================================================================
# Fig 1: Per-capita carbon burden by receiving city (No WH vs WH Plan 2)
# ======================================================================
fig, axes = plt.subplots(1, 3, figsize=(15, 5.5), sharey=True)
for ax, yr in zip(axes, [2026, 2030, 2035]):
    sub = df_city[(df_city["情景"]=="TAS算力转移") & (df_city["年份"]==yr)].copy()
    sub = sub.set_index("城市").reindex(C9)
    x = np.arange(len(C9)); w = 0.38
    ax.bar(x - w/2, sub["人均碳负担(tCO2/cap)"], w, color=COLOR['no_wh'],
           edgecolor='white', linewidth=0.5, label="No WH")
    ax.bar(x + w/2, sub["方案2非负化人均净负担(tCO2/cap)"], w,
           color=[city_color(c) for c in C9], edgecolor='white', linewidth=0.5,
           label="WH Plan 2")
    ax.set_yscale('log')
    ax.set_title(str(yr), fontsize=12, fontweight='bold')
    ax.set_xticks(x)
    ax.set_xticklabels([en(c) for c in C9], rotation=40, ha='right', fontsize=11)
    for tl, c in zip(ax.get_xticklabels(), C9):
        tl.set_color(city_color(c))
    ax.grid(axis='y', alpha=0.3, linestyle='--')
axes[0].set_ylabel("Per-capita carbon burden (tCO2/cap, log)", fontsize=12)
axes[0].legend(loc='upper left', fontsize=11, framealpha=0.9)
fig.suptitle("Fig 1  Per-capita Carbon Burden by Receiving City: No WH vs WH Plan 2",
             fontsize=13, fontweight='bold', y=1.02)
plt.savefig(os.path.join(OUT_DIR, "Fig1_burden_by_city.png"), dpi=300, bbox_inches='tight')
plt.close(); print("Fig1 done")

# ======================================================================
# Fig 2: Lorenz curve (2035 TAS)
# ======================================================================
fig, ax = plt.subplots(figsize=(7.5, 6.5))
sub = df_city[(df_city["情景"]=="TAS算力转移") & (df_city["年份"]==2035)].copy()
sub = sub.sort_values("人均碳负担(tCO2/cap)").reset_index(drop=True)
pop = sub["人口(万)"].values
burden = sub["人均碳负担(tCO2/cap)"].values * pop
net = sub["方案2非负化人均净负担(tCO2/cap)"].values * pop
cum_pop = np.insert(np.cumsum(pop)/pop.sum(), 0, 0)
cum_b = np.insert(np.cumsum(burden)/burden.sum(), 0, 0)
cum_n = np.insert(np.cumsum(net)/net.sum(), 0, 0)
ax.plot([0,1],[0,1],'--', color=COLOR['diag'], linewidth=1.5, label="Line of equality")
ax.plot(cum_pop, cum_b, 'o-', color=COLOR['no_wh'], linewidth=2.2, markersize=7,
        label="Carbon burden")
ax.plot(cum_pop, cum_n, 's-', color=COLOR['wh'], linewidth=2.2, markersize=7,
        label="Net burden")
for i, row in sub.iterrows():
    ax.annotate(en(row["城市"]), (cum_pop[i+1], cum_b[i+1]),
                textcoords="offset points", xytext=(6,4), fontsize=10,
                color=city_color(row["城市"]))
g = df_gini[(df_gini["情景"]=="TAS算力转移") & (df_gini["年份"]==2035)].iloc[0]
ax.text(0.15, 0.80, f"Gini(burden) = {g['Gini_人均碳负担(无余热)']:.3f}\n"
                    f"Gini(net, non-neg) = {g['Gini_人均净负担_非负化(方案2)']:.3f}\n"
                    f"Mitigation = {g['缓解效应_非负化(%)']:.2f}%",
        fontsize=11, bbox=dict(boxstyle='round,pad=0.4', facecolor='#FEF9E7', edgecolor='#F39C12'))
ax.set_xlabel("Cumulative population share", fontsize=12)
ax.set_ylabel("Cumulative carbon burden share", fontsize=12)
ax.set_title("Fig 2  Lorenz Curve: Carbon Burden Inequality (2035, TAS)", fontsize=12.5, fontweight='bold')
ax.legend(loc='upper left', fontsize=11)
ax.set_xlim(-0.02, 1.02); ax.set_ylim(-0.02, 1.02)
ax.grid(alpha=0.3, linestyle='--')
plt.savefig(os.path.join(OUT_DIR, "Fig2_lorenz_2035.png"), dpi=300, bbox_inches='tight')
plt.close(); print("Fig2 done")

# ======================================================================
# Fig 3: Gini index time series (2026-2035 TAS)
# ======================================================================
fig, ax = plt.subplots(figsize=(9, 5.5))
tg = df_gini[df_gini["情景"]=="TAS算力转移"].sort_values("年份")
ax.plot(tg["年份"], tg["Gini_人均碳负担(无余热)"], 'o-', color=COLOR['no_wh'],
        linewidth=2.2, markersize=7, label="No WH")
ax.plot(tg["年份"], tg["Gini_人均净负担_原始(方案2)"], 's--', color=COLOR['coal'],
        linewidth=1.8, markersize=6, label="Raw net burden")
ax.plot(tg["年份"], tg["Gini_人均净负担_非负化(方案2)"], 'D-', color=COLOR['wh'],
        linewidth=2.2, markersize=7, label="Non-neg net burden")
y35 = tg[tg["年份"]==2035].iloc[0]
ax.annotate(f"{y35['Gini_人均净负担_原始(方案2)']:.2f}\n(invalid)",
            (2035, y35['Gini_人均净负担_原始(方案2)']),
            textcoords="offset points", xytext=(-65, 10), fontsize=10, color=COLOR['coal'],
            arrowprops=dict(arrowstyle='->', color=COLOR['coal'], lw=1))
ax.annotate(f"{y35['Gini_人均净负担_非负化(方案2)']:.3f}\n(true effect)",
            (2035, y35['Gini_人均净负担_非负化(方案2)']),
            textcoords="offset points", xytext=(-45, -25), fontsize=10, color=COLOR['wh'],
            arrowprops=dict(arrowstyle='->', color=COLOR['wh'], lw=1))
ax.axhline(y=1.0, color='red', linestyle=':', alpha=0.5, linewidth=1)
ax.text(2026.2, 1.01, "Gini = 1 (threshold)", fontsize=10, color='red', alpha=0.7)
ax.set_xlabel("Year", fontsize=12)
ax.set_ylabel("Gini index", fontsize=12)
ax.set_title("Fig 3  Gini Index Time Series: WH Mitigation Effect (TAS, Plan 2)",
             fontsize=12.5, fontweight='bold')
ax.legend(loc='center left', fontsize=11, framealpha=0.9)
ax.grid(alpha=0.3, linestyle='--'); ax.set_ylim(0.85, 1.65)
plt.savefig(os.path.join(OUT_DIR, "Fig3_gini_timeseries.png"), dpi=300, bbox_inches='tight')
plt.close(); print("Fig3 done")

# ======================================================================
# Fig 4: Theil decomposition (2026-2035 TAS)
# ======================================================================
fig, ax1 = plt.subplots(figsize=(9, 5.5))
tg2 = df_gini[df_gini["情景"]=="TAS算力转移"].sort_values("年份")
tb = tg2["Theil_组间(煤电vs清洁)"].values
tw = tg2["Theil_组内"].values
yrs = tg2["年份"].values
ax1.bar(yrs, tb, color=COLOR['coal'], edgecolor='white', linewidth=0.5, label="Between (Coal vs Clean)")
ax1.bar(yrs, tw, bottom=tb, color=COLOR['clean_light'], edgecolor='white', linewidth=0.5, label="Within")
ax1.set_xlabel("Year", fontsize=12)
ax1.set_ylabel("Theil T index", fontsize=12, color='#333')
ax2 = ax1.twinx()
ax2.plot(yrs, tg2["组间贡献率(%)"], 'o-', color=COLOR['wh'], linewidth=2, markersize=6,
         label="Between share")
ax2.set_ylabel("Between share (%)", fontsize=12, color=COLOR['wh'])
ax2.tick_params(axis='y', labelcolor=COLOR['wh'])
ax2.set_ylim(45, 65)
lines1, labels1 = ax1.get_legend_handles_labels()
lines2, labels2 = ax2.get_legend_handles_labels()
ax1.legend(lines1 + lines2, labels1 + labels2, loc='upper left', fontsize=11, framealpha=0.9)
ax1.set_title("Fig 4  Theil Decomposition: Coal vs Clean Grid Drives Inequality",
              fontsize=12.5, fontweight='bold')
ax1.grid(axis='y', alpha=0.3, linestyle='--')
plt.savefig(os.path.join(OUT_DIR, "Fig4_theil_decomp.png"), dpi=300, bbox_inches='tight')
plt.close(); print("Fig4 done")

# ======================================================================
# Fig 5: Burden-benefit pairing scatter (2035 TAS)
# ======================================================================
fig, ax = plt.subplots(figsize=(8.5, 7))
sub = df_city[(df_city["情景"]=="TAS算力转移") & (df_city["年份"]==2035)].copy()
x = sub["人均碳负担(tCO2/cap)"].values
y = sub["方案2减排"].values * 1e6 / (sub["人口(万)"].values * 1e4)
mx = max(x.max(), y.max()) * 1.1
ax.plot([0.0003, mx], [0.0003, mx], '--', color=COLOR['diag'], linewidth=1.5, label="y = x")
OFFSET = {"成都":(9,-14),"重庆":(9,-4),"韶关":(-54,6),"芜湖":(-50,-8),
          "张家口":(-60,8),"贵阳":(9,8),"呼和浩特":(9,6),"庆阳":(9,6),"中卫":(-38,8)}
for c, xi, yi in zip(sub["城市"], x, y):
    ax.scatter(xi, yi, s=140, color=city_color(c), edgecolor='white', linewidth=1.2, zorder=5)
    dx, dy = OFFSET.get(c, (8, 6))
    ax.annotate(en(c), (xi, yi), textcoords="offset points", xytext=(dx, dy), fontsize=10,
                fontweight='bold', color=city_color(c))
ax.set_xscale('symlog', linthresh=0.1)
ax.set_yscale('symlog', linthresh=0.1)
ax.set_xlabel("Per-capita carbon burden (tCO2/cap, log)", fontsize=12)
ax.set_ylabel("Per-capita WH reduction (tCO2/cap, log)", fontsize=12)
ax.set_title("Fig 5  Burden-Benefit Pairing (2035, TAS)", fontsize=12.5, fontweight='bold')
ax.legend(loc='lower right', fontsize=11)
ax.grid(alpha=0.3, linestyle='--')
ax.set_xlim(1e-5, mx); ax.set_ylim(1e-5, mx*1.05)
ax.text(0.18, 0.88, "WH > Burden", fontsize=10, color=COLOR['clean'],
        transform=ax.transAxes, ha='center', alpha=0.7, style='italic')
ax.text(0.82, 0.12, "Burden > WH", fontsize=10, color=COLOR['coal'],
        transform=ax.transAxes, ha='center', alpha=0.7, style='italic')
plt.savefig(os.path.join(OUT_DIR, "Fig5_burden_benefit_pair.png"), dpi=300, bbox_inches='tight')
plt.close(); print("Fig5 done")

# ======================================================================
# Fig 6: 13-city net burden flow (2035 TAS)
# ======================================================================
fig, ax = plt.subplots(figsize=(9, 6.5))
sub13 = df_13[df_13["年份"]==2035].copy().sort_values("净负担(Mt)").reset_index(drop=True)
colors = [COLOR['source'] if r=="源" else COLOR['recv'] for r in sub13["角色"]]
bars = ax.barh([en(c) for c in sub13["城市"]], sub13["净负担(Mt)"], color=colors,
               edgecolor='white', linewidth=0.8)
for bar, val in zip(bars, sub13["净负担(Mt)"]):
    w = bar.get_width(); offset = 0.02 if w>=0 else -0.02
    ha = 'left' if w>=0 else 'right'
    ax.text(w+offset, bar.get_y()+bar.get_height()/2, f"{val:+.3f}",
            va='center', ha=ha, fontsize=10, color='#333')
ax.axvline(x=0, color='#333', linewidth=0.8)
ax.set_xlabel("Net carbon burden (Mt CO$_2$; + receiving, - source)", fontsize=12)
ax.set_title("Fig 6  Net Carbon Burden Flow across 13 Cities (2035, TAS)",
             fontsize=12.5, fontweight='bold')
ax.grid(axis='x', alpha=0.3, linestyle='--')
from matplotlib.patches import Patch
ax.legend(handles=[Patch(color=COLOR['source'], label="Source cities"),
                   Patch(color=COLOR['recv'], label="Receiving cities")],
          loc='lower right', fontsize=11, framealpha=0.9)
plt.savefig(os.path.join(OUT_DIR, "Fig6_13city_flow.png"), dpi=300, bbox_inches='tight')
plt.close(); print("Fig6 done")

print("\nAll 6 figures saved to:", OUT_DIR)

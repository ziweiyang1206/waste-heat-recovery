# -*- coding: utf-8 -*-
"""
08_compensation.py — Cross-regional compensation mechanism
Step 3 of the distributional analysis chain.

Framework (pool mode, simplest viable tradable-quota version):
  1. Liability  = non-negative net burden gap (承cities with positive net burden after WH)
  2. Payers     = 4 source cities (Beijing/Shanghai/Guangzhou/Shenzhen), share by GDP
  3. Receivers  = 6 receiver cities with positive gap, share by gap
  4. Compensation = total_gap x carbon_price (50/70/100 RMB/tCO2)
  5. Welfare change: receivers +compensation, payers -compensation

Outputs:
  Fig9_compensation_flow.png         — payer outflow vs receiver inflow
  Fig10_welfare_before_after.png     — per-capita net welfare change
  compensation_results.xlsx          — yearly_detail / compensation_2035 / welfare_change / method
"""
import pandas as pd
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import font_manager
import openpyxl
from openpyxl.styles import Font, Alignment, PatternFill, Border, Side

# ---------- global style: Arial 12pt ----------
plt.rcParams.update({
    "font.family": "Arial",
    "font.size": 12,
    "axes.titlesize": 13,
    "axes.labelsize": 12,
    "xtick.labelsize": 11,
    "ytick.labelsize": 11,
    "legend.fontsize": 10,
    "figure.dpi": 300,
    "savefig.dpi": 300,
    "axes.unicode_minus": False,
})

BASE = r"D:\杨紫薇\第五篇-算力转移导致的水能碳足迹流动\投稿\数据、代码及图源文件"
GINI = BASE + r"\碳不平等测算_Gini_Theil.xlsx"
PRED = BASE + r"\13城市人口GDP预测_2005-2035.xlsx"
DST  = BASE + r"\实验过程"

# ---------- city maps ----------
SRC4 = ["北京", "上海", "广州", "深圳"]                       # payers
T9   = ["成都", "重庆", "贵阳", "呼和浩特", "庆阳", "韶关", "芜湖", "张家口", "中卫"]
EN = {"北京":"Beijing", "上海":"Shanghai", "广州":"Guangzhou", "深圳":"Shenzhen",
      "成都":"Chengdu", "重庆":"Chongqing", "贵阳":"Guiyang", "呼和浩特":"Hohhot",
      "庆阳":"Qingyang", "韶关":"Shaoguan", "芜湖":"Wuhu", "张家口":"Zhangjiakou", "中卫":"Zhongwei"}
YEARS = list(range(2026, 2036))
PRICES = [50, 70, 100]   # RMB / tCO2

COLOR = {
    "payer":   "#4A90D9",   # blue (source cities, outflow)
    "receiver":"#E67E22",   # orange (receiver cities, inflow)
    "welfare_pos": "#27AE60",  # green (welfare gain)
    "welfare_neg": "#C0392B",  # red   (welfare loss)
    "price50": "#A8D5BA", "price70": "#5DADE2", "price100": "#2874A6",
    "diag": "#95A5A6",
}

# ============================================================
# 1. Read net burden gap (9 cities, total caliber, TAS scenario plan 2)
# ============================================================
df9 = pd.read_excel(GINI, sheet_name="9城碳负担与人均GDP")
df9 = df9[df9["情景"] == "TAS算力转移"].copy()
df9["净缺口"] = df9["方案2净负担(Mt)"].clip(lower=0)   # non-negative gap
df9["人均净缺口"] = df9["净缺口"] * 1e6 / (df9["人口(万)"] * 1e4)   # tCO2/cap

# ============================================================
# 2. Read source-city GDP (mid scenario)
# ============================================================
wb_pred = openpyxl.load_workbook(PRED, read_only=True)
ws_gdp = wb_pred["GDP_中情景"]
ws_pop = wb_pred["人口预测_2005-2035"]
COL = {ws_gdp.cell(row=1, column=j).value: j for j in range(1, ws_gdp.max_column+1) if ws_gdp.cell(row=1, column=j).value}
ROW = {y: y - 2005 + 2 for y in range(2005, 2036)}

def get_series(ws, city, years):
    c = COL[city]
    return [ws.cell(row=ROW[y], column=c).value for y in years]

src_gdp = {c: get_series(ws_gdp, c, YEARS) for c in SRC4}
src_pop = {c: get_series(ws_pop, c, YEARS) for c in SRC4}

# ============================================================
# 3. Compute compensation (pool mode)
# ============================================================
# For each year: total gap, payer share by GDP, receiver share by gap
yearly_rows = []
comp_2035_rows = []
welfare_rows = []

for i, y in enumerate(YEARS):
    sub = df9[df9["年份"] == y]
    # receivers: cities with positive gap
    recv = sub[sub["净缺口"] > 0].copy()
    recv_total = recv["净缺口"].sum()
    if recv_total <= 0:
        continue
    recv["share"] = recv["净缺口"] / recv_total
    # payers: 4 source cities, share by GDP
    gdp_sum = sum(src_gdp[c][i] for c in SRC4)
    payer_share = {c: src_gdp[c][i] / gdp_sum for c in SRC4}
    pop_sum = sum(src_pop[c][i] for c in SRC4)

    for price in PRICES:
        total_comp = recv_total * 1e6 * price / 1e8   # Mt->t (x1e6) * RMB/t / 1e8 = 亿元
        # per-city
        for _, r in recv.iterrows():
            city = r["城市"]
            amt = total_comp * r["share"]
            yearly_rows.append({
                "年份": y, "碳价": price,
                "类型": "接收", "城市": city, "角色": "receiver",
                "GDP(亿元)": r["GDP(亿元)"], "人口(万)": r["人口(万)"],
                "净缺口(Mt)": r["净缺口"], "份额": r["share"],
                "补偿额(亿元)": amt,
                "人均补偿(元/cap)": amt * 1e8 / (r["人口(万)"] * 1e4),
            })
            if y == 2035:
                comp_2035_rows.append(yearly_rows[-1])
        for c in SRC4:
            amt = total_comp * payer_share[c]
            yearly_rows.append({
                "年份": y, "碳价": price,
                "类型": "出资", "城市": c, "角色": "payer",
                "GDP(亿元)": src_gdp[c][i], "人口(万)": src_pop[c][i],
                "净缺口(Mt)": 0, "份额": payer_share[c],
                "补偿额(亿元)": amt,
                "人均补偿(元/cap)": amt * 1e8 / (src_pop[c][i] * 1e4),
            })
            if y == 2035:
                comp_2035_rows.append(yearly_rows[-1])

df_year = pd.DataFrame(yearly_rows)
df_2035 = pd.DataFrame(comp_2035_rows)

# ============================================================
# 4. Welfare change (2035, price=70 as baseline)
# ============================================================
PRICE_BASE = 70
sub35 = df9[df9["年份"] == 2035]
recv35 = sub35[sub35["净缺口"] > 0].copy()
recv35_total = recv35["净缺口"].sum()
total_comp35 = recv35_total * 1e6 * PRICE_BASE / 1e8   # 亿元

# receiver welfare: net burden (physical) monetized + compensation received
# before: net burden cost = net_gap * price (positive = loss)
# after:  net burden cost - compensation received
for _, r in recv35.iterrows():
    share = r["净缺口"] / recv35_total
    comp = total_comp35 * share
    burden_cost = r["净缺口"] * 1e6 * PRICE_BASE / 1e8   # 亿元
    pop = r["人口(万)"] * 1e4
    welfare_rows.append({
        "城市": r["城市"], "角色": "receiver",
        "净缺口(Mt)": r["净缺口"],
        "补偿前净损失(亿元)": burden_cost,
        "补偿额(亿元)": comp,
        "补偿后净损失(亿元)": burden_cost - comp,
        "补偿前人均损失(元/cap)": burden_cost * 1e8 / pop,
        "补偿后人均损失(元/cap)": (burden_cost - comp) * 1e8 / pop,
        "人均福利改善(元/cap)": comp * 1e8 / pop,
        "缓解率(%)": comp / burden_cost * 100 if burden_cost > 0 else None,
    })

# payer welfare: only cost, no physical burden
gdp_sum35 = sum(src_gdp[c][YEARS.index(2035)] for c in SRC4)
for c in SRC4:
    i = YEARS.index(2035)
    share = src_gdp[c][i] / gdp_sum35
    comp = total_comp35 * share
    pop = src_pop[c][i] * 1e4
    welfare_rows.append({
        "城市": c, "角色": "payer",
        "净缺口(Mt)": 0,
        "补偿前净损失(亿元)": 0,
        "补偿额(亿元)": -comp,   # negative = outflow
        "补偿后净损失(亿元)": -comp,
        "补偿前人均损失(元/cap)": 0,
        "补偿后人均损失(元/cap)": -comp * 1e8 / pop,
        "人均福利改善(元/cap)": -comp * 1e8 / pop,
        "缓解率(%)": None,
    })

df_welfare = pd.DataFrame(welfare_rows)

# ============================================================
# 5. Print key results
# ============================================================
print("=" * 80)
print("COMPENSATION MECHANISM — 2035 TAS Plan-2 (total caliber)")
print("=" * 80)
print(f"\nTotal net gap (receivers): {recv35_total:.3f} Mt CO2")
print(f"Payers (GDP share, mid scenario):")
for c in SRC4:
    i = YEARS.index(2035)
    print(f"  {EN[c]:<12} GDP={src_gdp[c][i]:.0f}亿  share={src_gdp[c][i]/gdp_sum35*100:.1f}%")
print(f"\nReceivers (gap share):")
for _, r in recv35.sort_values("净缺口", ascending=False).iterrows():
    print(f"  {EN[r['城市']]:<12} gap={r['净缺口']:.3f}Mt  share={r['净缺口']/recv35_total*100:.1f}%")

print(f"\nTotal compensation @ carbon price:")
for p in PRICES:
    print(f"  {p} RMB/t -> {recv35_total*1e6*p/1e8:.2f} 亿元")

print(f"\nWelfare change @ {PRICE_BASE} RMB/t (2035):")
print(df_welfare[["城市","角色","补偿前人均损失(元/cap)","补偿后人均损失(元/cap)","人均福利改善(元/cap)","缓解率(%)"]].to_string(index=False))

# ============================================================
# 6. Fig 9 — Payer outflow vs Receiver inflow (2035, 3 prices)
# ============================================================
fig, ax = plt.subplots(figsize=(11, 6.5))

# left side: payers (outflow, negative bars)
# right side: receivers (inflow, positive bars)
recv_sorted = recv35.sort_values("净缺口", ascending=True).reset_index(drop=True)
n_recv = len(recv_sorted)
n_payer = len(SRC4)

# positions: payers on left (x<0), receivers on right (x>0)
y_pos_payer = np.arange(n_payer)
y_pos_recv = np.arange(n_payer + 1, n_payer + 1 + n_recv)

bar_h = 0.25
colors_price = [COLOR["price50"], COLOR["price70"], COLOR["price100"]]

for k, price in enumerate(PRICES):
    total = recv35_total * 1e6 * price / 1e8
    # payers
    for j, c in enumerate(SRC4):
        i = YEARS.index(2035)
        share = src_gdp[c][i] / gdp_sum35
        amt = total * share
        ax.barh(y_pos_payer[j] + (k-1)*bar_h, -amt, height=bar_h,
                color=colors_price[k], edgecolor="white", linewidth=0.5)
    # receivers
    for j, (_, r) in enumerate(recv_sorted.iterrows()):
        share = r["净缺口"] / recv35_total
        amt = total * share
        ax.barh(y_pos_recv[j] + (k-1)*bar_h, amt, height=bar_h,
                color=colors_price[k], edgecolor="white", linewidth=0.5)

# labels
ax.set_yticks(np.concatenate([y_pos_payer, y_pos_recv]))
labels = [EN[c] for c in SRC4] + [EN[r["城市"]] for _, r in recv_sorted.iterrows()]
ax.set_yticklabels(labels)
ax.set_xlabel("Compensation flow (100 million RMB)", fontsize=12)

# divider
ax.axvline(0, color="#555", linewidth=1)
ax.text(-5.8, -0.8, "Payers (outflow)", fontsize=11, ha="left", va="center",
        color=COLOR["payer"], fontweight="bold")
ax.text(3.2, 3.2, "Receivers (inflow)", fontsize=11, ha="left", va="center",
        color=COLOR["receiver"], fontweight="bold")

# legend
from matplotlib.patches import Patch
handles = [Patch(facecolor=colors_price[k], label=f"Carbon price = {PRICES[k]} RMB/t") for k in range(3)]
ax.legend(handles=handles, loc="lower right", frameon=True, edgecolor="#ccc")

ax.set_title("Cross-regional compensation flow (2035, TAS Plan-2)", fontsize=13, pad=12)
ax.grid(axis="x", alpha=0.3, linestyle="--")
ax.invert_yaxis()
plt.tight_layout()
plt.savefig(f"{DST}/Fig9_compensation_flow.png", bbox_inches="tight", facecolor="white")
plt.close()
print("\n[Fig9 saved]")

# ============================================================
# 7. Fig 10 — Per-capita welfare: before vs full vs partial (50%) compensation
# ============================================================
fig, ax = plt.subplots(figsize=(11.5, 6.2))

# receivers (6 cities with positive gap)
wf_recv = df_welfare[df_welfare["角色"]=="receiver"].sort_values("人均福利改善(元/cap)", ascending=True).reset_index(drop=True)
cities = [EN[c] for c in wf_recv["城市"]]
before = wf_recv["补偿前人均损失(元/cap)"].values
after_full = wf_recv["补偿后人均损失(元/cap)"].values   # = 0 (100% pool)
after_half = before * 0.5                               # 50% partial compensation scenario

x = np.arange(len(cities))
w = 0.26
b1 = ax.bar(x - w,     before,      w, label="Before compensation",        color=COLOR["welfare_neg"], edgecolor="white")
b2 = ax.bar(x,         after_half,  w, label="After 50% compensation",      color="#E67E22", edgecolor="white")
b3 = ax.bar(x + w,     after_full,  w, label="After 100% compensation",     color=COLOR["welfare_pos"], edgecolor="white")

# annotate residual loss for partial scenario
for i, (b, a) in enumerate(zip(before, after_half)):
    ax.annotate(f"{a:.0f}", xy=(x[i], a), xytext=(0, 3),
                textcoords="offset points", ha="center", fontsize=9.5, color="#B9540B", fontweight="bold")

ax.set_xticks(x)
ax.set_xticklabels(cities, rotation=20, ha="right")
ax.set_ylabel("Per-capita residual loss (RMB/cap)", fontsize=12)
ax.set_title(f"Residual burden under full vs partial compensation (2035, {PRICE_BASE} RMB/t)", fontsize=13, pad=12)
ax.legend(loc="upper left", frameon=True, edgecolor="#ccc")
ax.grid(axis="y", alpha=0.3, linestyle="--")
ax.axhline(0, color="#555", linewidth=0.8)
plt.tight_layout()
plt.savefig(f"{DST}/Fig10_welfare_before_after.png", bbox_inches="tight", facecolor="white")
plt.close()
print("[Fig10 saved]")

# ============================================================
# 8. Write Excel
# ============================================================
OUT = f"{DST}/compensation_results.xlsx"
with pd.ExcelWriter(OUT, engine="openpyxl") as writer:
    df_year.to_excel(writer, sheet_name="yearly_detail", index=False)
    df_2035.to_excel(writer, sheet_name="compensation_2035", index=False)
    df_welfare.to_excel(writer, sheet_name="welfare_change", index=False)
    # method
    method = pd.DataFrame([
        ["Framework", "Pool mode: 4 source cities (payers) fund 6 receiver cities (gap>0)"],
        ["Liability", "Non-negative net burden gap after WH recovery (TAS Plan-2, total caliber)"],
        ["Payer share", "By GDP (mid scenario), reflecting consumption-side responsibility"],
        ["Receiver share", "By net gap, proportional to residual burden"],
        ["Carbon price", "50 / 70 / 100 RMB per tCO2 (sensitivity)"],
        ["Baseline price", "70 RMB/t for welfare-change figure"],
        ["", ""],
        ["Key finding 1", "Total compensation need @ 70 RMB/t = %.2f 亿元 (2035)" % (recv35_total*1e6*70/1e8)],
        ["Key finding 2", "Hohhot (gap 6.26 Mt) receives 63.2% of pool; Zhongwei (2.97 Mt) 30.0%"],
        ["Key finding 3", "Payer burden: Shanghai highest (GDP share 31.9%), Beijing 28.8%, Shenzhen 22.9%, Guangzhou 16.4%"],
        ["Key finding 4", "Per-capita: Zhongwei relief largest (compensation/gap ratio ~100% by design); Hohhot partial"],
        ["", ""],
        ["Caveat", "Pool mode assumes full internalization. Real-world implementation may use bilateral pairing or tradable permits."],
        ["Caveat", "Source-city EF (0.208-0.269) all lower than high-EF receivers (Hohhot 0.665, Zhongwei 0.452) — confirms East-to-West computing migration increases emissions, establishing compensation liability."],
    ], columns=["Item", "Description"])
    method.to_excel(writer, sheet_name="method", index=False)

# style
wb = openpyxl.load_workbook(OUT)
for sn in wb.sheetnames:
    ws = wb[sn]
    ws.column_dimensions["A"].width = 14
    for col in "BCDEFGHIJK":
        ws.column_dimensions[col].width = 16
    for row in ws.iter_rows():
        for c in row:
            c.font = Font(name="Arial", size=10)
            c.alignment = Alignment(horizontal="left", vertical="center")
wb.save(OUT)
print(f"\n[Excel saved] {OUT}")
print("\nDone.")

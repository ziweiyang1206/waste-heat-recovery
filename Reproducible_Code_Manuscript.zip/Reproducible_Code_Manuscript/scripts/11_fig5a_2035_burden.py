# -*- coding: utf-8 -*-
"""
Fig5a_2035_burden.py — Single-panel per-capita carbon burden (2035 TAS) for Fig.5a.
Requirements: only 2035; city labels vertical (90 deg), black; adjusted colors.
No WH = gray; WH Plan 2 = coal-heavy group red / clean group blue (echoes Fig.5b-d).
"""
import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib as mpl

mpl.rcParams['font.family'] = 'Arial'
mpl.rcParams['font.size'] = 12
mpl.rcParams['axes.linewidth'] = 1.0
mpl.rcParams['figure.dpi'] = 100
mpl.rcParams['savefig.dpi'] = 300
mpl.rcParams['savefig.bbox'] = 'tight'

COLOR = {'coal': '#E74C3C', 'clean': '#3498DB', 'no_wh': '#95A5A6', 'wh': '#E67E22'}
CN2EN = {'成都':'Chengdu','重庆':'Chongqing','贵阳':'Guiyang','韶关':'Shaoguan',
         '芜湖':'Wuhu','呼和浩特':'Hohhot','庆阳':'Qingyang','张家口':'Zhangjiakou',
         '中卫':'Zhongwei'}
GROUP_COAL = ['呼和浩特','张家口','芜湖','庆阳','中卫']
GROUP_CLEAN = ['成都','重庆','贵阳','韶关']
C9 = GROUP_COAL + GROUP_CLEAN
def city_color(c): return COLOR['coal'] if c in GROUP_COAL else COLOR['clean']
def en(c): return CN2EN.get(c, c)

BASE = r"D:\杨紫薇\第五篇-算力转移导致的水能碳足迹流动\投稿\数据、代码及图源文件"
GINI_XLSX = BASE + r"\碳不平等测算_Gini_Theil.xlsx"
OUT_DIR = BASE + r"\实验过程"

df_city = pd.read_excel(GINI_XLSX, sheet_name="9城碳负担与人均GDP")
sub = df_city[(df_city["情景"]=="TAS算力转移") & (df_city["年份"]==2035)].copy()
sub = sub.set_index("城市").reindex(C9)

x = np.arange(len(C9)); w = 0.38
fig, ax = plt.subplots(figsize=(8.5, 5.5))
ax.bar(x - w/2, sub["人均碳负担(tCO2/cap)"], w, color=COLOR['no_wh'],
       edgecolor='white', linewidth=0.5, label="No WH")
ax.bar(x + w/2, sub["方案2非负化人均净负担(tCO2/cap)"], w,
       color=[city_color(c) for c in C9], edgecolor='white', linewidth=0.5,
       label="WH Plan 2")
ax.set_yscale('log')
ax.set_xticks(x)
ax.set_xticklabels([en(c) for c in C9], rotation=90, ha='center', fontsize=11, color='black')
ax.set_ylabel("Per-capita carbon burden (tCO2/cap, log)")
ax.legend(loc='upper left', fontsize=11, framealpha=0.9)
ax.grid(axis='y', alpha=0.3, linestyle='--')
plt.tight_layout()
plt.savefig(os.path.join(OUT_DIR, "Fig5a_percap_burden_2035.png"), dpi=300, bbox_inches='tight')
plt.close(); print("Fig5a saved")

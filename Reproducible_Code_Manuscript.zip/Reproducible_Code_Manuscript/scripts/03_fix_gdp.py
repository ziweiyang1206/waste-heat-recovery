# -*- coding: utf-8 -*-
import pandas as pd
import openpyxl
from openpyxl.styles import PatternFill

BASE = r"D:/杨紫薇/第五篇-算力转移导致的水能碳足迹流动/投稿/数据、代码及图源文件"
GDPX = BASE + r"\数据汇总\2000-2024地级市GDP相关指标.xlsx"
WB   = BASE + r"\13城市人口GDP历史数据收集清单.xlsx"
CITIES = ["北京","上海","广州","深圳","成都","重庆","张家口","芜湖","韶关","呼和浩特","贵阳","庆阳","中卫"]
ROW_OF = {y: y-2005+4 for y in range(2005,2026)}
COL_OF = {c: i+2 for i,c in enumerate(CITIES)}
YELLOW = PatternFill("solid", fgColor="FFF9E79F")
BLUE   = PatternFill("solid", fgColor="FFD6EAF8")

gdf = pd.read_excel(GDPX, sheet_name="2000-2024")
gdf.columns = [str(c).strip() for c in gdf.columns]
gdf["key"] = gdf["城市"].astype(str).str.strip().str.replace("市","",regex=False)
gpiv = (gdf[gdf["key"].isin(CITIES)].pivot_table(index="年份", columns="key", values="GDP(万元)", aggfunc="first")/1e4).reindex(columns=CITIES)

wb = openpyxl.load_workbook(WB)
wsg = wb["GDP数据填写模板"]
replaced = []
for c in CITIES:
    col = COL_OF[c]
    for y in [2020, 2021, 2022, 2023]:
        r = ROW_OF[y]
        cur = wsg.cell(row=r, column=col).value
        f = gpiv.loc[y, c]
        if pd.isna(f):
            continue
        if cur is None or abs(float(cur) - f)/max(f,1) > 0.02:
            old = cur
            cell = wsg.cell(row=r, column=col, value=round(float(f), 2))
            cell.fill = BLUE
            replaced.append((c, y, old, round(float(f),2)))
wb.save(WB)

print("== 替换为五经普修订序列的格子 ==")
for x in replaced:
    print(f"  {x[0]} {x[1]}: {x[2]} -> {x[3]}")

# 替换后 2020-2025 增速检查
wb2 = openpyxl.load_workbook(WB)
wsg2 = wb2["GDP数据填写模板"]
print("\n== 替换后 2020→2025 名义增速序列（%-相邻年） ==")
for c in CITIES:
    col = COL_OF[c]
    vals = [float(wsg2.cell(row=ROW_OF[y], column=col).value) for y in range(2020,2026)]
    gr = [f"{vals[i+1]/vals[i]*100-100:+.1f}" for i in range(5)]
    print(f"  {c}: " + "%  ".join(gr) + "%")

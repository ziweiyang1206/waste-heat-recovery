# -*- coding: utf-8 -*-
"""13城市人口(Logistic/von Bertalanffy)与GDP(增速收敛)预测 2005-2035"""
import numpy as np
import pandas as pd
import openpyxl
from scipy.optimize import curve_fit
from openpyxl.styles import Font, Alignment, PatternFill, Border, Side

WB_SRC = r"D:\杨紫薇\第五篇-算力转移导致的水能碳足迹流动\投稿\数据、代码及图源文件\13城市人口GDP历史数据收集清单.xlsx"
WB_OUT = r"D:\杨紫薇\第五篇-算力转移导致的水能碳足迹流动\投稿\数据、代码及图源文件\13城市人口GDP预测_2005-2035.xlsx"
CITIES = ["北京","上海","广州","深圳","成都","重庆","张家口","芜湖","韶关","呼和浩特","贵阳","庆阳","中卫"]
PROV   = {"北京":"直辖市","上海":"直辖市","广州":"广东","深圳":"广东","成都":"四川","重庆":"直辖市",
          "张家口":"河北","芜湖":"安徽","韶关":"广东","呼和浩特":"内蒙古","贵阳":"贵州","庆阳":"甘肃","中卫":"宁夏"}
GROUP  = {"北京":"源","上海":"源","广州":"源","深圳":"源","成都":"承接","重庆":"承接","张家口":"承接",
          "芜湖":"承接","韶关":"承接","呼和浩特":"承接","贵阳":"承接","庆阳":"承接","中卫":"承接"}
ROW_OF = {y: y - 2005 + 4 for y in range(2005, 2026)}
COL_OF = {c: i + 2 for i, c in enumerate(CITIES)}

# ---------- 读取历史 ----------
def read_panel(sheet):
    wb = openpyxl.load_workbook(WB_SRC)
    ws = wb[sheet]
    data = {}
    for c in CITIES:
        col = COL_OF[c]
        series = []
        for y in range(2005, 2026):
            v = ws.cell(row=ROW_OF[y], column=col).value
            series.append(float(v) if v is not None else None)
        data[c] = series
    return data

pop_hist = read_panel("人口数据填写模板")
gdp_hist = read_panel("GDP数据填写模板")
YEARS_H = list(range(2005, 2026))

# ---------- 人口预测：von Bertalanffy ----------
def bertalanffy(t, K, r, P0):
    """P(t)=K-(K-P0)*exp(-r*(t-t0)); 单调逼近K，处理增长与收缩"""
    return K - (K - P0) * np.exp(-r * t)

def fit_pop(city, series):
    P0 = series[0]  # 2005
    P_2025 = series[-1]
    t = np.arange(len(YEARS_H), dtype=float)
    P = np.array(series, dtype=float)
    # 初值猜测
    if P_2025 > P0:
        K0 = P_2025 * 1.08
    elif P_2025 < P0:
        K0 = P_2025 * 0.95
    else:
        K0 = P_2025
    r0 = 0.05
    try:
        popt, _ = curve_fit(bertalanffy, t, P, p0=[K0, r0, P0],
                            bounds=([P_2025*0.5 if P_2025<P0 else P_2025, 0.001, P0*0.8],
                                    [P_2025*1.3 if P_2025>P0 else P_2025*1.05, 0.5, P0*1.2]),
                            maxfev=20000)
        K, r, Pf0 = popt
        pred_hist = bertalanffy(t, K, r, Pf0)
        ss_res = np.sum((P - pred_hist) ** 2)
        ss_tot = np.sum((P - P.mean()) ** 2)
        r2 = 1 - ss_res / ss_tot if ss_tot > 0 else 1.0
        t_pred = np.arange(len(YEARS_H), len(YEARS_H) + 10, dtype=float)  # 2026-2035
        pred = bertalanffy(t_pred, K, r, Pf0)
        return {"K": K, "r": r, "P0_fit": Pf0, "R2": r2, "pred_2026_2035": pred.tolist(),
                "status": "bertalanffy"}
    except Exception as e:
        # fallback: 最近5年线性外推，向2025值收敛
        last5 = np.array(series[-5:], dtype=float)
        yrs = np.arange(2021, 2026)
        slope, intercept = np.polyfit(yrs, last5, 1)
        pred = []
        for y in range(2026, 2036):
            v = slope * y + intercept
            # 向2025值温和拉回（收缩50%惯性）
            v = P_2025 + (v - P_2025) * 0.5
            pred.append(max(v, P_2025 * 0.9))
        return {"K": None, "r": None, "P0_fit": P0, "R2": None, "pred_2026_2035": pred,
                "status": f"linear_fallback({type(e).__name__})"}

# ---------- GDP预测：增速收敛 ----------
def fit_gdp(series):
    n = len(series)  # 21 (2005-2025)
    # 最后3段增速：index n-4→n-3(2022→23), n-3→n-2(23→24), n-2→n-1(24→25)
    g0_list = []
    for i in [n - 4, n - 3, n - 2]:
        if series[i] and series[i + 1] and series[i] > 0:
            g0_list.append((series[i + 1] / series[i] - 1) * 100)
    g0 = np.mean(g0_list) if g0_list else 5.0
    base = series[-1]  # 2025
    scenarios = {}
    for sname, ginf, lam in [("高情景", 3.5, 0.10), ("中情景", 2.5, 0.10), ("低情景", 1.5, 0.10)]:
        pred = []
        v = base
        for k in range(10):  # 2026-2035
            gt = g0 * np.exp(-lam * (k + 1)) + ginf
            v = v * (1 + gt / 100)
            pred.append(v)
        scenarios[sname] = {"g0": g0, "g_inf": ginf, "lambda": lam, "pred_2026_2035": pred}
    return scenarios

# ---------- 运行 ----------
pop_result, gdp_result = {}, {}
for c in CITIES:
    pop_result[c] = fit_pop(c, pop_hist[c])
    gdp_result[c] = fit_gdp(gdp_hist[c])

# ---------- 打印诊断 ----------
print("== 人口预测诊断 ==")
for c in CITIES:
    r = pop_result[c]
    p30 = r["pred_2026_2035"][4]  # 2030
    p35 = r["pred_2026_2035"][9]  # 2035
    kstr = f"{r['K']:.1f}" if r['K'] is not None else "N/A"
    rstr = f"{r['r']:.4f}" if r['r'] is not None else "0"
    r2str = f"{r['R2']:.3f}" if r['R2'] is not None else "0"
    print(f"  {c}: K={kstr} r={rstr} R2={r2str} | 2025={pop_hist[c][-1]:.1f} -> 2030={p30:.1f} -> 2035={p35:.1f} [{r['status']}]")
print("\n== GDP预测诊断（中情景） ==")
for c in CITIES:
    r = gdp_result[c]["中情景"]
    print(f"  {c}: g0={r['g0']:.1f}% g_inf={r['g_inf']}% | 2025={gdp_hist[c][-1]:.0f} → 2030={r['pred_2026_2035'][4]:.0f} → 2035={r['pred_2026_2035'][9]:.0f}")

# ---------- 写Excel ----------
def style_header(ws, ncol):
    hd = PatternFill("solid", fgColor="FF1F4E78")
    ft = Font(name="微软雅黑", size=11, bold=True, color="FFFFFFFF")
    bd = Border(left=Side("thin", color="FFBFBFBF"), right=Side("thin", color="FFBFBFBF"),
                top=Side("thin", color="FFBFBFBF"), bottom=Side("thin", color="FFBFBFBF"))
    for j in range(1, ncol + 1):
        cell = ws.cell(row=1, column=j)
        cell.fill = hd; cell.font = ft; cell.border = bd
        cell.alignment = Alignment(horizontal="center", vertical="center")

wb = openpyxl.Workbook()

# Sheet1: 人口预测
ws = wb.active; ws.title = "人口预测_2005-2035"
hdr = ["年份"] + CITIES
ws.append(hdr); style_header(ws, len(hdr))
for i, y in enumerate(YEARS_H):
    ws.append([y] + [round(pop_hist[c][i], 1) for c in CITIES])
for k, y in enumerate(range(2026, 2036)):
    ws.append([y] + [round(pop_result[c]["pred_2026_2035"][k], 1) for c in CITIES])
# 标注2025/2026分界
ws.cell(row=22, column=1).comment = None
for j in range(1, len(hdr)+1):
    ws.cell(row=22, column=j).fill = PatternFill("solid", fgColor="FFFFF2CC")

# Sheet2-4: GDP三情景
for sname in ["高情景", "中情景", "低情景"]:
    ws = wb.create_sheet(f"GDP_{sname}")
    ws.append(hdr); style_header(ws, len(hdr))
    for i, y in enumerate(YEARS_H):
        ws.append([y] + [round(gdp_hist[c][i], 2) for c in CITIES])
    for k, y in enumerate(range(2026, 2036)):
        ws.append([y] + [round(gdp_result[c][sname]["pred_2026_2035"][k], 2) for c in CITIES])
    for j in range(1, len(hdr)+1):
        ws.cell(row=22, column=j).fill = PatternFill("solid", fgColor="FFFFF2CC")

# Sheet5: 拟合参数与方法
ws = wb.create_sheet("方法与参数")
rows = [
    ["城市", "组别", "省份", "人口K(万)", "人口r", "人口R²", "人口2025→2035Δ%",
     "GDP g0(%)", "GDP g∞(中)", "GDP 2025→2035(中)Δ%", "GDP 2025→2035(高)Δ%", "GDP 2025→2035(低)Δ%"],
]
for c in CITIES:
    pr = pop_result[c]
    gr = gdp_result[c]
    p25, p35 = pop_hist[c][-1], pr["pred_2026_2035"][9]
    g25, g35m = gdp_hist[c][-1], gr["中情景"]["pred_2026_2035"][9]
    g35h, g35l = gr["高情景"]["pred_2026_2035"][9], gr["低情景"]["pred_2026_2035"][9]
    rows.append([c, GROUP[c], PROV[c],
                 round(pr["K"],1) if pr["K"] else "N/A",
                 round(pr["r"],4) if pr["r"] else "N/A",
                 round(pr["R2"],3) if pr["R2"] else "N/A",
                 round((p35/p25-1)*100,1),
                 round(gr["中情景"]["g0"],1),
                 gr["中情景"]["g_inf"],
                 round((g35m/g25-1)*100,1),
                 round((g35h/g25-1)*100,1),
                 round((g35l/g25-1)*100,1)])
for r in rows:
    ws.append(r)
style_header(ws, len(rows[0]))

# Sheet6: 方法说明
ws = wb.create_sheet("方法说明")
notes = [
    ["一、人口预测：von Bertalanffy 模型", ""],
    ["模型形式", "P(t) = K - (K - P0)·exp(-r·(t-t0))"],
    ["特点", "单调逼近渐近值K；K>2025值时单调增长（如贵阳），K<2025值时单调下降（如张家口、庆阳），K≈2025值时平台期（如北京、上海、深圳）。"],
    ["拟合区间", "2005-2025（21个历史点），scipy.optimize.curve_fit 最小二乘。"],
    ["P0", "拟合参数（不固定为2005实测值，由拟合确定）。"],
    ["数据来源", "《13城市人口GDP历史数据收集清单》人口模板（2005-2019来自298城密度表，2020-2024来自城市面板，2025来自各市统计公报，已通过六普/七普校核）。"],
    ["回退策略", "若拟合失败（R²<0或异常），采用2021-2025线性外推并向2025锚点50%拉回，结果保证温和合理。"],
    ["", ""],
    ["二、GDP预测：名义增速收敛法", ""],
    ["模型形式", "g_t = g0·exp(-λ·(t-2025)) + g∞"],
    ["g0", "2022-2025三段（22→23, 23→24, 24→25）名义增速均值，避开2021疫情反弹段。"],
    ["g∞", "长期稳态名义增速。中情景2.5%（对应实际增速1.5%+通胀1%）；高情景3.5%；低情景1.5%。"],
    ["λ", "收敛速率0.10，使2030年增速约为(g0+g∞)/2，2035年接近g∞+（g0-g∞)·e^(-1}。"],
    ["GDP_t", "GDP_{t-1}·(1+g_t/100)，递推2026-2035。"],
    ["数据来源", "GDP模板：2005-2019当年核实数（面板），2020-2023五经普回溯修订序列，2024-2025各市公报。"],
    ["", ""],
    ["三、与论文BS/TAS情景的衔接", ""],
    ["用途", "人口/GDP预测作为分母（人均碳负担、单位GDP碳负担）用于Gini/Theil不平等测算，不直接进入算力转移情景。"],
    ["情景对应", "GDP高/中/低三情景可作为BS/TAS的敏感性上下界；主结果用中情景。"],
    ["不确定性", "人口Logistic对2025锚点敏感，2035预测区间约±5%；GDP g∞假设区间±1pct，2035预测区间约±15%。"],
]
for r in notes:
    ws.append(r)
ws.column_dimensions["A"].width = 28; ws.column_dimensions["B"].width = 90

wb.save(WB_OUT)
print(f"\n✓ 预测结果已写入: {WB_OUT}")

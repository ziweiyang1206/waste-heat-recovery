# -*- coding: utf-8 -*-
"""
10_robust_inequality.py
补CV/RMD/Atkinson作为对负值稳健的并行指标，验证WHR加剧相对不平等结论。
CV和RMD天然处理负值；Atkinson用zero-floored口径。
所有指标采用人口加权口径，与05 Gini/Theil和07 DCEA C指数同口径（居民间不平等）。
"""
import numpy as np
import pandas as pd
import openpyxl
from openpyxl.styles import Font, Alignment, PatternFill, Border, Side

GINI = r"D:\杨紫薇\第五篇-算力转移导致的水能碳足迹流动\投稿\数据、代码及图源文件\碳不平等测算_Gini_Theil.xlsx"
DST  = r"D:\杨紫薇\第五篇-算力转移导致的水能碳足迹流动\投稿\数据、代码及图源文件\实验过程"

YEARS = list(range(2026, 2036))
T9 = ["Chengdu","Chongqing","Guiyang","Hohhot","Qingyang",
      "Shaoguan","Wuhu","Zhangjiakou","Zhongwei"]

# ---------- 读9城碳负担与人均GDP ----------
df = pd.read_excel(GINI, sheet_name="9城碳负担与人均GDP")
# 列名适配
burden_col = [c for c in df.columns if "碳负担" in c and "Mt" in c][0]
wh2_col    = [c for c in df.columns if "方案2减排" in c][0]
pop_col    = [c for c in df.columns if "人口" in c][0]

def cv(x, w=None):
    """人口加权变异系数 = sqrt(Σw·(x-μ_w)²) / |μ_w|，可处理负值"""
    x = np.asarray(x, float)
    n = len(x)
    if w is None: w = np.ones(n)/n
    w = np.asarray(w, float); w = w/w.sum()
    mu = np.sum(w*x)
    if abs(mu) < 1e-12: return np.nan
    var = np.sum(w*(x-mu)**2)
    return np.sqrt(var)/abs(mu)

def rmd(x, w=None):
    """人口加权相对均值绝对偏差 = Σw·|x-μ_w| / |μ_w|，可处理负值"""
    x = np.asarray(x, float)
    n = len(x)
    if w is None: w = np.ones(n)/n
    w = np.asarray(w, float); w = w/w.sum()
    mu = np.sum(w*x)
    if abs(mu) < 1e-12: return np.nan
    return np.sum(w*np.abs(x - mu)) / abs(mu)

def atkinson(x, eps=0.5, w=None):
    """人口加权Atkinson指数（需正值，用zero-floored口径）"""
    x = np.asarray(x, float)
    n = len(x)
    if w is None: w = np.ones(n)/n
    w = np.asarray(w, float); w = w/w.sum()
    x = np.maximum(x, 0)  # zero-floor
    mu = np.sum(w*x)
    if mu < 1e-12: return np.nan
    if abs(eps - 1.0) < 1e-6:
        pos = x > 0
        if not pos.any(): return np.nan
        wp = w[pos]/w[pos].sum()
        gm = np.exp(np.sum(wp*np.log(x[pos])))
        return 1 - gm/mu
    else:
        return 1 - (np.sum(w*(x/mu)**(1-eps)))**(1/(1-eps))

# ---------- 计算三指标（baseline vs WHR后） ----------
rows = []
for scn in ["BS基准","TAS算力转移"]:
    for y in YEARS:
        sub = df[(df["情景"]==scn) & (df["年份"]==y)]
        if len(sub) < 9: continue
        burden = sub[burden_col].values
        wh     = sub[wh2_col].values
        pop    = sub[pop_col].values
        per_burden = burden * 1e6 / (pop * 1e4)   # Mt→t, 万→人
        per_net    = (burden - wh) * 1e6 / (pop * 1e4)
        per_net_zf = np.maximum(per_net, 0)

        cv_b   = cv(per_burden, pop)     # 人口加权
        cv_n   = cv(per_net, pop)
        rmd_b  = rmd(per_burden, pop)
        rmd_n  = rmd(per_net, pop)
        a05_b  = atkinson(per_burden, 0.5, pop)
        a05_n  = atkinson(per_net_zf, 0.5, pop)
        a10_b  = atkinson(per_burden, 1.0, pop)
        a10_n  = atkinson(per_net_zf, 1.0, pop)

        rows.append({
            "情景": scn, "年份": y,
            "CV_baseline": cv_b, "CV_net_raw": cv_n,
            "CV变化(%)": (cv_n/cv_b - 1)*100 if cv_b else np.nan,
            "RMD_baseline": rmd_b, "RMD_net_raw": rmd_n,
            "RMD变化(%)": (rmd_n/rmd_b - 1)*100 if rmd_b else np.nan,
            "Atk0.5_baseline": a05_b, "Atk0.5_net_zf": a05_n,
            "Atk0.5变化(%)": (a05_n/a05_b - 1)*100 if a05_b else np.nan,
            "Atk1.0_baseline": a10_b, "Atk1.0_net_zf": a10_n,
            "Atk1.0变化(%)": (a10_n/a10_b - 1)*100 if a10_b else np.nan,
        })
res = pd.DataFrame(rows)

# ---------- 输出到Excel ----------
out_xlsx = f"{DST}/robust_inequality_indices.xlsx"
with pd.ExcelWriter(out_xlsx, engine="openpyxl") as xl:
    res.to_excel(xl, sheet_name="稳健指标对比", index=False)
    # 关键年份摘要
    summary = res[res["年份"].isin([2026,2030,2035])][[
        "情景","年份","CV_baseline","CV_net_raw","CV变化(%)",
        "RMD_baseline","RMD_net_raw","RMD变化(%)",
        "Atk0.5_baseline","Atk0.5_net_zf","Atk0.5变化(%)",
        "Atk1.0_baseline","Atk1.0_net_zf","Atk1.0变化(%)"
    ]].round(4)
    summary.to_excel(xl, sheet_name="关键年份摘要", index=False)

    # 方法说明
    method = pd.DataFrame([
        ["CV", "变异系数 std/|mean|，天然处理负值，>0表示存在离散，上升=不平等加剧"],
        ["RMD", "相对均值绝对偏差 mean|x-μ|/|μ|，天然处理负值，上升=不平等加剧"],
        ["Atkinson ε=0.5", "需正值，用zero-floored口径(max(x,0))，上升=不平等加剧"],
        ["Atkinson ε=1.0", "需正值，用zero-floored口径，上升=不平等加剧"],
        ["baseline", "无WHR的人均碳负担"],
        ["net_raw", "WHR后人均净负担（含负值，CV/RMD用此口径）"],
        ["net_zf", "WHR后人均净负担截断为0（Atkinson用此口径）"],
        ["判断标准", "若CV/RMD/Atkinson变化均为正→WHR加剧相对不平等结论稳健"],
    ], columns=["指标","说明"])
    method.to_excel(xl, sheet_name="方法说明", index=False)

print("=== 稳健指标验证结果（TAS情景，方案2 WHR）===")
for y in [2026, 2030, 2035]:
    r = res[(res["情景"]=="TAS算力转移") & (res["年份"]==y)].iloc[0]
    print(f"\n{y}:")
    print(f"  CV:   baseline={r['CV_baseline']:.4f} → net={r['CV_net_raw']:.4f}  变化={r['CV变化(%)']:+.2f}%")
    print(f"  RMD:  baseline={r['RMD_baseline']:.4f} → net={r['RMD_net_raw']:.4f}  变化={r['RMD变化(%)']:+.2f}%")
    print(f"  Atk0.5(zf): {r['Atk0.5_baseline']:.4f} → {r['Atk0.5_net_zf']:.4f}  变化={r['Atk0.5变化(%)']:+.2f}%")
    print(f"  Atk1.0(zf): {r['Atk1.0_baseline']:.4f} → {r['Atk1.0_net_zf']:.4f}  变化={r['Atk1.0变化(%)']:+.2f}%")

# 判定
all_pass = True
for _, r in res.iterrows():
    if r["CV变化(%)"] is not np.nan and r["CV变化(%)"] <= 0: all_pass = False; break
    if r["RMD变化(%)"] is not np.nan and r["RMD变化(%)"] <= 0: all_pass = False; break
print(f"\n=== CV/RMD变化全部为正（WHR加剧相对不平等）: {'PASS ✓' if all_pass else 'FAIL ✗'} ===")
print(f"\n[robust_inequality_indices.xlsx saved]")

# -*- coding: utf-8 -*-
"""
09_sensitivity.py — Flow-share & EF sensitivity analysis (population-weighted)
Addresses reviewer concern: "compensation is uncertain-built-on-uncertain"

All inequality indices (Gini, Theil_between, C_index) use POPULATION-WEIGHTED
caliber, aligned with 05_gini_theil and 07_DCEA. Equal-weight caliber removed
to ensure three-layer framework consistency (burden Gini = benefit C-index =
compensation, all population-weighted = resident-level inequality).

Three uncertainty dimensions:
  D1. Transfer-volume perturbation (4 structured + MC ±20%/±50%, from-source)
      -> perturbs the scenario-design transfer volume itself; shows the
         inequality measures are robust to how the transfer volume is set
  D2. Emission factor (EF) bounds (low=high-speed scenario / high=baseline scenario)
      -> EF is the true driver; tests if conclusions hold across EF range
  D3. Combined (volume ±50% × EF bounds, MC 300 runs)
      -> full uncertainty envelope with 95% CIs

Core conclusions tested:
  C1: Gini (per-capita burden, pop-weighted) > 0.7  [baseline 0.90]
  C2: Mitigation effect (non-neg) < 0                [baseline -3.32%]
  C3: Loss center = Hohhot (total) / Zhongwei (per-cap)
  C4: Positive total gap (need compensation)
  C5: C_benefit < 0 (WH pro-poor)                    [baseline -0.111]
"""
import pandas as pd
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import openpyxl
from openpyxl.styles import Font, Alignment

plt.rcParams.update({
    "font.family": "Arial", "font.size": 12,
    "axes.titlesize": 13, "axes.labelsize": 12,
    "xtick.labelsize": 11, "ytick.labelsize": 11,
    "legend.fontsize": 9, "figure.dpi": 300, "savefig.dpi": 300,
    "axes.unicode_minus": False,
})

BASE = r"D:\杨紫薇\第五篇-算力转移导致的水能碳足迹流动\投稿\数据、代码及图源文件"
LINKS = BASE + r"\数据汇总\情景一_增量转移_算力_能耗_热量_碳排放_总表_统一口径版.csv"
TOTAL  = BASE + r"\数据汇总\情景一_存量+增量_总负荷_总表.csv"
EFCSV  = BASE + r"\数据汇总\九大城市2026-2035电网碳排放因子_线性插值.csv"
GINI   = BASE + r"\碳不平等测算_Gini_Theil.xlsx"
DST    = BASE + r"\实验过程"
PRICE = 70

T9_EN = ["Chengdu","Chongqing","Guiyang","Hohhot","Qingyang","Shaoguan","Wuhu","Zhangjiakou","Zhongwei"]
T9_CN = ["成都","重庆","贵阳","呼和浩特","庆阳","韶关","芜湖","张家口","中卫"]
CN2EN = dict(zip(T9_CN, T9_EN))
GROUP9 = {"Hohhot":"Coal","Zhangjiakou":"Coal","Wuhu":"Coal","Qingyang":"Coal","Zhongwei":"Coal",
          "Chengdu":"Clean","Chongqing":"Clean","Guiyang":"Clean","Shaoguan":"Clean"}

# ============================================================
# 1. Load baseline data (2035)
# ============================================================
# Link-level (incremental)
df_links = pd.read_csv(LINKS)
df35 = df_links[df_links["年份"]==2035].copy().reset_index(drop=True)
ef_map = df35.groupby("Target")["emission factor (kgCO2/kWh)"].first().to_dict()

# Stock+Total load table
df_tot = pd.read_csv(TOTAL)
df_tot35 = df_tot[df_tot["年份"]==2035].copy()
# City column is English in this file
total_energy = dict(zip(df_tot35["城市"], df_tot35["S1_Total_Energy (TWh)"]))
stock_energy = dict(zip(df_tot35["城市"], df_tot35["Stock_Energy (TWh)"]))
incr_energy_base = dict(zip(df_tot35["城市"], df_tot35["S1_Increment_Energy (TWh)"]))

# 9-city burden/WH/pop/GDP from Gini Excel (TAS, total caliber)
df9 = pd.read_excel(GINI, sheet_name="9城碳负担与人均GDP")
df9_35 = df9[(df9["情景"]=="TAS算力转移") & (df9["年份"]==2035)].copy()
df9_35["key"] = df9_35["城市"].map(CN2EN)
burden_base = dict(zip(df9_35["key"], df9_35["碳负担(Mt)"]))
wh_base = dict(zip(df9_35["key"], df9_35["方案2减排"]))
pop_map = dict(zip(df9_35["key"], df9_35["人口(万)"]))
gdp_map = dict(zip(df9_35["key"], df9_35["GDP(亿元)"]))
base_incr_burden = {c: 0.0 for c in T9_EN}
base_weights = {}
for _, r in df35.iterrows():
    base_weights[(r["Source"], r["Target"])] = r["Energy (TWh)"]
    base_incr_burden[r["Target"]] += r["Energy (TWh)"] * ef_map[r["Target"]]

# Baseline incremental energy per target
base_incr_energy = {c: 0.0 for c in T9_EN}
for (s, t), e in base_weights.items():
    base_incr_energy[t] += e

# Stock burden = total - incremental
stock_burden = {c: burden_base[c] - base_incr_burden[c] for c in T9_EN}

# Incremental WH ratio = incr_energy / total_energy
incr_ratio = {c: base_incr_energy[c] / total_energy[c] if total_energy[c] > 0 else 0 for c in T9_EN}
stock_wh = {c: wh_base[c] * (1 - incr_ratio[c]) for c in T9_EN}
base_incr_wh = {c: wh_base[c] * incr_ratio[c] for c in T9_EN}

print("Baseline verification (2035):")
for c in T9_EN:
    rb = stock_burden[c] + base_incr_burden[c]
    rw = stock_wh[c] + base_incr_wh[c]
    print(f"  {c:<12} total_burden={burden_base[c]:.3f}(recomputed {rb:.3f})  incr_ratio={incr_ratio[c]*100:.2f}%  WH={wh_base[c]:.3f}(recomputed {rw:.3f})")

# EF bounds from CSV (current = low/high-speed; high = need table2 upper)
# For 2035, current CSV has high-speed (lower bound). Upper bound ~1.2x for coal, 1.1x for clean
ef_low = dict(zip(df_tot35["城市"], df_tot35["emission factor (kgCO2/kWh)"]))  # current = high-speed scenario
# Approximate upper bound (baseline scenario) from literature: coal ~1.15x, clean ~1.10x
ef_high = {c: ef_low[c] * (1.15 if GROUP9[c]=="Coal" else 1.10) for c in T9_EN}

# ============================================================
# 2. Core functions
# ============================================================
def gini(x, w=None):
    """Population-weighted Gini (w=None => equal-weight). Handles negatives.
    Aligned with 05_gini_theil and 07_DCEA.c_weighted (same caliber)."""
    x = np.asarray(x, dtype=float)
    n = len(x)
    if n == 0: return np.nan
    if w is None:
        w = np.ones(n)/n
    w = np.asarray(w, dtype=float)
    w = w/w.sum()
    mu = np.sum(w*x)
    if abs(mu) < 1e-15: return np.nan
    order = np.argsort(x)
    xs, ws = x[order], w[order]
    R = np.cumsum(ws) - ws/2
    return float((2.0/mu) * np.sum(ws * (xs - mu) * (R - 0.5)))

def theil_between(x, groups, w=None):
    """Population-weighted Theil between-group share (w=None => equal-weight). Requires all positive."""
    x = np.asarray(x, dtype=float); groups = np.asarray(groups)
    n = len(x)
    if w is None:
        w = np.ones(n)/n
    w = np.asarray(w, dtype=float)
    w = w/w.sum()
    mu = np.sum(w*x)
    if abs(mu) < 1e-15 or (x<=0).any(): return np.nan
    T_total = np.sum(w * (x/mu) * np.log(x/mu))
    T_between = 0
    for g in np.unique(groups):
        mask = groups==g
        wg = w[mask]; xg = x[mask]
        Wg = wg.sum()
        mug = np.sum(wg*xg)/Wg
        T_between += Wg * (mug/mu) * np.log(mug/mu)
    return float(T_between/T_total*100) if T_total else np.nan

def c_index(y, w):
    """Population-weighted concentration index (same as 07_DCEA.c_weighted).
    NOTE: y and w must already be sorted by GDP (poor->rich) before calling."""
    y = np.asarray(y, float); w = np.asarray(w, float)
    w_share = w / w.sum()
    R = np.cumsum(w_share) - w_share/2
    mu = np.sum(w_share * y)
    if abs(mu) < 1e-12: return np.nan
    return float((2.0/mu) * np.sum(w_share * (y - mu) * (R - 0.5)))

def recompute(new_energies, ef_override=None):
    """new_energies: dict {(source,target): energy_TWh}; ef_override: dict city->ef or None"""
    ef = ef_override if ef_override else ef_map
    # New incremental burden
    new_incr_burden = {c: 0.0 for c in T9_EN}
    new_incr_energy = {c: 0.0 for c in T9_EN}
    for (s, t), e in new_energies.items():
        if t in T9_EN:
            new_incr_burden[t] += e * ef[t]
            new_incr_energy[t] += e
    # Total burden = stock + new incremental (stock uses baseline EF? No—stock burden is fixed physical)
    # NOTE: stock burden is physical (already emitted), doesn't change with EF perturbation
    # But for EF sensitivity, we recompute BOTH stock and incremental with new EF
    # Simplification: stock_burden is from baseline; for EF perturbation, scale stock by ef_ratio
    burden = {}
    wh = {}
    for c in T9_EN:
        if ef_override:
            # EF perturbation: recompute both stock and incremental
            ef_ratio = ef[c] / ef_map[c]
            burden[c] = (stock_burden[c] + new_incr_burden[c])  # incr already uses new ef
            # stock burden scaled by ef_ratio (since stock_carbon = stock_energy * ef)
            burden[c] = stock_burden[c] * ef_ratio + new_incr_burden[c]
        else:
            burden[c] = stock_burden[c] + new_incr_burden[c]
        # WH: incremental scales with energy ratio
        ratio = new_incr_energy[c] / base_incr_energy[c] if base_incr_energy[c] > 0 else 0
        wh[c] = stock_wh[c] + base_incr_wh[c] * ratio
        # WH also depends on EF (heating displacement uses grid EF)
        if ef_override:
            wh[c] = wh[c] * (ef[c] / ef_map[c])

    net = {c: burden[c] - wh[c] for c in T9_EN}
    net_nn = {c: max(net[c], 0) for c in T9_EN}
    pop = {c: pop_map[c]*1e4 for c in T9_EN}
    pc_burden = np.array([burden[c]*1e6/pop[c] for c in T9_EN])
    pc_net_nn = np.array([net_nn[c]*1e6/pop[c] for c in T9_EN])
    # 人口加权Gini/Theil（与05/07同口径）
    pop_w = np.array([pop_map[c] for c in T9_EN])  # 万人，用作权重

    g_burden = gini(pc_burden, pop_w)
    g_net_nn = gini(pc_net_nn, pop_w)
    mitig_nn = (g_burden - g_net_nn)/g_burden*100 if g_burden else np.nan
    grps = [GROUP9[c] for c in T9_EN]
    between_pct = theil_between(pc_burden, grps, pop_w)

    gdp_arr = np.array([gdp_map[c] for c in T9_EN])
    pop_arr = np.array([pop_map[c] for c in T9_EN])
    benefit = np.array([wh[c] for c in T9_EN])
    cost = np.array([burden[c] for c in T9_EN])
    net_arr = benefit - cost
    net_nn_arr = np.array([max(v,0) for v in net_arr])
    gdp_pc = gdp_arr / pop_arr
    order = np.argsort(gdp_pc)   # sort by GDP per capita (poor->rich)
    # c_index expects y, w already sorted by GDP
    c_ben = c_index(benefit[order], pop_arr[order])
    c_cost = c_index(cost[order], pop_arr[order])
    c_net_nn = c_index(net_nn_arr[order], pop_arr[order])

    total_gap = sum(net_nn[c] for c in T9_EN)
    comp = total_gap * 1e6 * PRICE / 1e8
    pc_loss = {c: net_nn[c]*1e6/pop[c] for c in T9_EN}
    total_loss = {c: net_nn[c] for c in T9_EN}
    return {
        "gini_burden": g_burden, "gini_net_nn": g_net_nn, "mitig_nn": mitig_nn,
        "theil_between_pct": between_pct,
        "c_benefit": c_ben, "c_cost": c_cost, "c_net_nn": c_net_nn,
        "total_gap_Mt": total_gap, "comp_billion": comp,
        "top_total": max(total_loss, key=total_loss.get),
        "top_pc": max(pc_loss, key=pc_loss.get),
    }

# ============================================================
# 3. Weight schemes
# ============================================================
src_targets = {}
for (s, t), e in base_weights.items():
    src_targets.setdefault(s, []).append(t)
src_total = {}
for (s, t), e in base_weights.items():
    src_total[s] = src_total.get(s, 0) + e

def make_equal():
    w = {}
    for s, tgts in src_targets.items():
        sh = src_total[s] / len(tgts)
        for t in tgts: w[(s,t)] = sh
    return w

def make_ef_weight(reverse=False):
    w = {}
    for s, tgts in src_targets.items():
        efs = np.array([ef_map[t] for t in tgts])
        weights = 1.0/(efs+1e-6) if reverse else efs.copy()
        weights /= weights.sum()
        for i, t in enumerate(tgts): w[(s,t)] = src_total[s]*weights[i]
    return w

def perturb(delta, rng):
    """From-source perturbation of the TRANSFER VOLUME itself (NOT conserved).
    Each link's transferred volume is perturbed independently, so the migration
    total changes — this perturbs the scenario-design parameter (transfer volume)
    at the source, instead of only reshuffling allocation among targets."""
    w = {}
    for (s, t), e in base_weights.items():
        w[(s, t)] = e * rng.uniform(1 - delta, 1 + delta)
    return w

# ============================================================
# 4. Run scenarios
# ============================================================
results = []

# --- D1: Weight schemes (baseline EF) ---
r0 = recompute(base_weights); r0.update({"dim":"D1_weight","scheme":"Baseline","ef":"base"}); results.append(r0)
for name, w in [("Equal_split",make_equal()), ("LowEF_priority",make_ef_weight(True)), ("HighEF_priority",make_ef_weight(False))]:
    r = recompute(w); r.update({"dim":"D1_weight","scheme":name,"ef":"base"}); results.append(r)

# --- D1: MC transfer-volume perturbation (from-source, not conserved) ---
rng = np.random.default_rng(42)
for delta in [0.20, 0.50]:
    for i in range(200):
        w = perturb(delta, rng)
        r = recompute(w); r.update({"dim":"D1_volume","scheme":f"MC_vol{int(delta*100)}","ef":"base","run":i}); results.append(r)

# --- D2: EF bounds (baseline weights) ---
for ef_name, ef_dict in [("EF_low", ef_low), ("EF_high", ef_high)]:
    r = recompute(base_weights, ef_dict); r.update({"dim":"D2_ef","scheme":ef_name,"ef":ef_name}); results.append(r)

# --- D2: MC EF perturbation (uniform between low and high) ---
for i in range(200):
    ef_rand = {}
    for c in T9_EN:
        lo, hi = ef_low[c], ef_high[c]
        ef_rand[c] = rng.uniform(lo, hi)
    r = recompute(base_weights, ef_rand); r.update({"dim":"D2_ef","scheme":"MC_ef","ef":"random","run":i}); results.append(r)

# --- D3: Combined (weight ±50% × EF random) ---
for i in range(300):
    w = perturb(0.50, rng)
    ef_rand = {c: rng.uniform(ef_low[c], ef_high[c]) for c in T9_EN}
    r = recompute(w, ef_rand); r.update({"dim":"D3_combined","scheme":"MC_combined","ef":"random","run":i}); results.append(r)

df_res = pd.DataFrame(results)

# ============================================================
# 5. Print results
# ============================================================
print("\n" + "="*80)
print("SENSITIVITY ANALYSIS — 2035 TAS Plan-2")
print("="*80)

print("\n--- D1: Transfer-volume perturbation (structured) ---")
for r in results[:4]:
    print(f"  [{r['scheme']:<16}] Gini={r['gini_burden']:.4f} mitig_nn={r['mitig_nn']:.2f}% between={r['theil_between_pct']:.1f}% "
          f"C_ben={r['c_benefit']:.4f} comp={r['comp_billion']:.2f}亿 top_t={r['top_total']} top_pc={r['top_pc']}")

for label in ["MC_vol20","MC_vol50"]:
    sub = df_res[(df_res["scheme"]==label)]
    print(f"\n  [{label}] (200 runs)")
    print(f"    Gini:    {sub['gini_burden'].mean():.4f}  95%CI=[{sub['gini_burden'].quantile(.025):.4f}, {sub['gini_burden'].quantile(.975):.4f}]")
    print(f"    Mitig:   {sub['mitig_nn'].mean():.2f}%  95%CI=[{sub['mitig_nn'].quantile(.025):.2f}, {sub['mitig_nn'].quantile(.975):.2f}]")
    print(f"    C_ben:   {sub['c_benefit'].mean():.4f}  95%CI=[{sub['c_benefit'].quantile(.025):.4f}, {sub['c_benefit'].quantile(.975):.4f}]")
    print(f"    Comp:    {sub['comp_billion'].mean():.2f}亿  95%CI=[{sub['comp_billion'].quantile(.025):.2f}, {sub['comp_billion'].quantile(.975):.2f}]")
    print(f"    Hohhot_top={(sub['top_total']=='Hohhot').mean()*100:.0f}%  Zhongwei_top_pc={(sub['top_pc']=='Zhongwei').mean()*100:.0f}%")

print("\n--- D2: EF perturbation ---")
for r in [x for x in results if x.get("dim")=="D2_ef" and x.get("scheme") in ["EF_low","EF_high"]]:
    print(f"  [{r['scheme']:<8}] Gini={r['gini_burden']:.4f} mitig={r['mitig_nn']:.2f}% between={r['theil_between_pct']:.1f}% "
          f"C_ben={r['c_benefit']:.4f} comp={r['comp_billion']:.2f}亿")
sub_ef = df_res[df_res["scheme"]=="MC_ef"]
print(f"\n  [MC_ef] (200 runs)")
print(f"    Gini:    {sub_ef['gini_burden'].mean():.4f}  95%CI=[{sub_ef['gini_burden'].quantile(.025):.4f}, {sub_ef['gini_burden'].quantile(.975):.4f}]")
print(f"    Mitig:   {sub_ef['mitig_nn'].mean():.2f}%  95%CI=[{sub_ef['mitig_nn'].quantile(.025):.2f}, {sub_ef['mitig_nn'].quantile(.975):.2f}]")
print(f"    C_ben:   {sub_ef['c_benefit'].mean():.4f}  95%CI=[{sub_ef['c_benefit'].quantile(.025):.4f}, {sub_ef['c_benefit'].quantile(.975):.4f}]")
print(f"    Comp:    {sub_ef['comp_billion'].mean():.2f}亿  95%CI=[{sub_ef['comp_billion'].quantile(.025):.2f}, {sub_ef['comp_billion'].quantile(.975):.2f}]")

print("\n--- D3: Combined (transfer volume ±50% × EF random, 300 runs) ---")
sub_c = df_res[df_res["scheme"]=="MC_combined"]
print(f"  Gini:    {sub_c['gini_burden'].mean():.4f}  95%CI=[{sub_c['gini_burden'].quantile(.025):.4f}, {sub_c['gini_burden'].quantile(.975):.4f}]")
print(f"  Mitig:   {sub_c['mitig_nn'].mean():.2f}%  95%CI=[{sub_c['mitig_nn'].quantile(.025):.2f}, {sub_c['mitig_nn'].quantile(.975):.2f}]")
print(f"  C_ben:   {sub_c['c_benefit'].mean():.4f}  95%CI=[{sub_c['c_benefit'].quantile(.025):.4f}, {sub_c['c_benefit'].quantile(.975):.4f}]")
print(f"  Comp:    {sub_c['comp_billion'].mean():.2f}亿  95%CI=[{sub_c['comp_billion'].quantile(.025):.2f}, {sub_c['comp_billion'].quantile(.975):.2f}]")
print(f"  Hohhot_top={(sub_c['top_total']=='Hohhot').mean()*100:.0f}%  Zhongwei_top_pc={(sub_c['top_pc']=='Zhongwei').mean()*100:.0f}%")

# Robustness verdict
print("\n" + "="*80)
print("ROBUSTNESS VERDICT (across ALL scenarios)")
print("="*80)
all_g = df_res["gini_burden"].dropna()
all_m = df_res["mitig_nn"].dropna()
all_c = df_res["c_benefit"].dropna()
all_gap = df_res["total_gap_Mt"]
def verdict(cond, label, detail):
    print(f"  [{'PASS' if cond else 'FAIL'}] {label}: {detail}")

verdict(all_g.min()>0.7, "C1 Gini>0.7", f"min={all_g.min():.4f} max={all_g.max():.4f}")
verdict(all_m.max()<0, "C2 mitig_nn<0", f"max={all_m.max():.2f}% (all negative)")
verdict((df_res["top_total"]=="Hohhot").mean()*100>80, "C3a top_total=Hohhot", f"{(df_res['top_total']=='Hohhot').mean()*100:.0f}%")
verdict((df_res["top_pc"]=="Zhongwei").mean()*100>80, "C3b top_pc=Zhongwei", f"{(df_res['top_pc']=='Zhongwei').mean()*100:.0f}%")
verdict((all_gap>0).all(), "C4 positive gap", f"min={all_gap.min():.3f}Mt")
verdict((all_c<0).mean()*100>80, "C5 C_benefit<0 pro-poor", f"{(all_c<0).mean()*100:.0f}% of runs")

# ============================================================
# 6. Figures
# ============================================================
DISPLAY = {"MC_vol20":"Transfer volume \u00b120%","MC_vol50":"Transfer volume \u00b150%",
           "MC_ef":"Emission factor","MC_combined":"Combined"}
fig, axes = plt.subplots(2, 2, figsize=(13, 9))

# Gini by dimension
ax = axes[0,0]
for label, color in [("MC_vol20","#3498DB"),("MC_vol50","#27AE60"),("MC_ef","#E67E22"),("MC_combined","#C0392B")]:
    sub = df_res[df_res["scheme"]==label]
    if len(sub)>0:
        ax.hist(sub["gini_burden"].dropna(), bins=25, histtype='step', linewidth=1.6, color=color, label=DISPLAY.get(label, label))
ax.axvline(0.7, color="red", linestyle="--", lw=1.5, label="0.7 threshold")
for name, marker in [("Baseline","*"),("Equal_split","D"),("LowEF_priority","^"),("HighEF_priority","v"),("EF_low","s"),("EF_high","p")]:
    r = df_res[df_res["scheme"]==name]
    if len(r)>0:
        ax.scatter(r.iloc[0]["gini_burden"], 3, marker=marker, s=70, zorder=5, label=name)
ax.set_xlabel("Gini (per-capita burden)"); ax.set_ylabel("Count")
ax.legend(fontsize=7, loc="upper left"); ax.grid(alpha=.3, linestyle="--")

# Mitigation
ax = axes[0,1]
for label, color in [("MC_vol20","#3498DB"),("MC_vol50","#27AE60"),("MC_ef","#E67E22"),("MC_combined","#C0392B")]:
    sub = df_res[df_res["scheme"]==label]
    if len(sub)>0:
        ax.hist(sub["mitig_nn"].dropna(), bins=25, histtype='step', linewidth=1.6, color=color, label=DISPLAY.get(label, label))
ax.axvline(0, color="red", linestyle="--", lw=1.5, label="0 threshold")
ax.set_xlabel("Mitigation effect (%)"); ax.set_ylabel("Count")
ax.legend(fontsize=7, loc="upper left"); ax.grid(alpha=.3, linestyle="--")

# C_benefit
ax = axes[1,0]
for label, color in [("MC_vol20","#3498DB"),("MC_vol50","#27AE60"),("MC_ef","#E67E22"),("MC_combined","#C0392B")]:
    sub = df_res[df_res["scheme"]==label]
    if len(sub)>0:
        ax.hist(sub["c_benefit"].dropna(), bins=25, histtype='step', linewidth=1.6, color=color, label=DISPLAY.get(label, label))
ax.axvline(0, color="red", linestyle="--", lw=1.5, label="0 threshold")
ax.set_xlabel("C_benefit (pro-poor if <0)"); ax.set_ylabel("Count")
ax.legend(fontsize=7, loc="upper left"); ax.grid(alpha=.3, linestyle="--")

# Compensation
ax = axes[1,1]
for label, color in [("MC_vol20","#3498DB"),("MC_vol50","#27AE60"),("MC_ef","#E67E22"),("MC_combined","#C0392B")]:
    sub = df_res[df_res["scheme"]==label]
    if len(sub)>0:
        ax.hist(sub["comp_billion"].dropna(), bins=25, histtype='step', linewidth=1.6, color=color, label=DISPLAY.get(label, label))
ax.set_xlabel("Total compensation (100M RMB)"); ax.set_ylabel("Count")
ax.legend(fontsize=7, loc="upper right"); ax.grid(alpha=.3, linestyle="--")

plt.tight_layout()
plt.savefig(f"{DST}/Fig11_sensitivity_distributions.png", bbox_inches="tight", facecolor="white")
plt.close()
print("\n[Fig11 saved]")

# ============================================================
# 7. Excel
# ============================================================
OUT = f"{DST}/sensitivity_results.xlsx"
struct = df_res[~df_res["scheme"].str.startswith("MC")][["dim","scheme","ef","gini_burden","gini_net_nn","mitig_nn",
    "theil_between_pct","c_benefit","c_cost","c_net_nn","total_gap_Mt","comp_billion","top_total","top_pc"]]

mc_summary = []
for label in ["MC_vol20","MC_vol50","MC_ef","MC_combined"]:
    sub = df_res[df_res["scheme"]==label]
    if len(sub)==0: continue
    mc_summary.append({
        "scheme": label, "runs": len(sub),
        "Gini_mean": sub["gini_burden"].mean(), "Gini_95low": sub["gini_burden"].quantile(.025), "Gini_95high": sub["gini_burden"].quantile(.975),
        "Mitig_mean": sub["mitig_nn"].mean(), "Mitig_95low": sub["mitig_nn"].quantile(.025), "Mitig_95high": sub["mitig_nn"].quantile(.975),
        "C_ben_mean": sub["c_benefit"].mean(), "C_ben_95low": sub["c_benefit"].quantile(.025), "C_ben_95high": sub["c_benefit"].quantile(.975),
        "Comp_mean": sub["comp_billion"].mean(), "Comp_95low": sub["comp_billion"].quantile(.025), "Comp_95high": sub["comp_billion"].quantile(.975),
        "Hohhot_pct": (sub["top_total"]=="Hohhot").mean()*100, "Zhongwei_pct": (sub["top_pc"]=="Zhongwei").mean()*100,
    })

verdict_df = pd.DataFrame([
    ["C1","Gini>0.7",f"{all_g.min():.4f}-{all_g.max():.4f}","PASS" if all_g.min()>0.7 else "FAIL"],
    ["C2","Mitig_nn<0",f"max={all_m.max():.2f}%","PASS" if all_m.max()<0 else "FAIL"],
    ["C3a","top_total=Hohhot",f"{(df_res['top_total']=='Hohhot').mean()*100:.0f}%","PASS" if (df_res['top_total']=='Hohhot').mean()*100>80 else "FAIL"],
    ["C3b","top_pc=Zhongwei",f"{(df_res['top_pc']=='Zhongwei').mean()*100:.0f}%","PASS" if (df_res['top_pc']=='Zhongwei').mean()*100>80 else "FAIL"],
    ["C4","positive gap",f"{all_gap.min():.3f}-{all_gap.max():.3f}Mt","PASS" if (all_gap>0).all() else "FAIL"],
    ["C5","C_benefit<0",f"{(all_c<0).mean()*100:.0f}%","PASS" if (all_c<0).mean()*100>80 else "FAIL"],
], columns=["ID","Conclusion","Range","Verdict"])

with pd.ExcelWriter(OUT, engine="openpyxl") as w:
    struct.to_excel(w, sheet_name="structured", index=False)
    pd.DataFrame(mc_summary).to_excel(w, sheet_name="MC_summary", index=False)
    verdict_df.to_excel(w, sheet_name="verdict", index=False)

wb = openpyxl.load_workbook(OUT)
for sn in wb.sheetnames:
    ws = wb[sn]
    for col in "ABCDEFGHIJKLMN": ws.column_dimensions[col].width=16
    for row in ws.iter_rows():
        for c in row: c.font = Font(name="Arial", size=10)
wb.save(OUT)
print(f"[Excel saved] {OUT}")
print("\nDone.")

# -*- coding: utf-8 -*-
"""
12_fig5_combined.py — Full Fig.5 (2x2) Inequality diagnosis.
a: per-capita burden 2035 (WHR legend split coal/clean red/blue)
b: Gini time series   c: Lorenz curve   d: Theil decomposition
All subplots: no titles; full term "waste heat recovery" (no WH/WHR).
"""
import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib as mpl

mpl.rcParams['font.family'] = 'Arial'
mpl.rcParams['font.size'] = 12
mpl.rcParams['axes.linewidth'] = 1.0
mpl.rcParams['figure.dpi'] = 100
mpl.rcParams['savefig.dpi'] = 300
mpl.rcParams['savefig.bbox'] = 'tight'

C = {'coal': '#E74C3C', 'clean': '#3498DB', 'gray': '#95A5A6',
     'clean_light': '#AED6F1', 'wh': '#E67E22', 'no_wh': '#2C3E50', 'diag': '#7F8C8D'}
CN2EN = {'成都':'Chengdu','重庆':'Chongqing','贵阳':'Guiyang','韶关':'Shaoguan',
         '芜湖':'Wuhu','呼和浩特':'Hohhot','庆阳':'Qingyang','张家口':'Zhangjiakou',
         '中卫':'Zhongwei'}
GROUP_COAL = ['呼和浩特','张家口','芜湖','庆阳','中卫']
GROUP_CLEAN = ['成都','重庆','贵阳','韶关']
C9 = GROUP_COAL + GROUP_CLEAN
def en(c): return CN2EN.get(c, c)
# 9 distinguishable colors for city markers on the Lorenz curve (burden-ascending order)
CITY_ASC = ['成都','重庆','贵阳','韶关','张家口','芜湖','庆阳','呼和浩特','中卫']
CITY_COLOR = dict(zip(CITY_ASC,
    ['#0072B2','#D55E00','#009E73','#CC79A7','#E6AB02','#56B4E9','#E69F00','#999999','#882255']))

BASE = r"D:\杨紫薇\第五篇-算力转移导致的水能碳足迹流动\投稿\数据、代码及图源文件"
GINI_XLSX = BASE + r"\碳不平等测算_Gini_Theil.xlsx"
OUT = BASE + r"\实验过程"
df_city = pd.read_excel(GINI_XLSX, sheet_name="9城碳负担与人均GDP")
df_gini = pd.read_excel(GINI_XLSX, sheet_name="Gini_Theil指数")

fig, axes = plt.subplots(2, 2, figsize=(12, 9.5))

# ---------------- (a) Per-capita burden 2035 ----------------
ax = axes[0,0]
sub = df_city[(df_city["情景"]=="TAS算力转移") & (df_city["年份"]==2035)].set_index("城市").reindex(C9)
x = np.arange(len(C9)); w = 0.38
ax.bar(x - w/2, sub["人均碳负担(tCO2/cap)"], w, color=C['gray'],
       edgecolor='white', linewidth=0.5, label="Without waste heat recovery")
coal_idx = [C9.index(c) for c in GROUP_COAL]; clean_idx = [C9.index(c) for c in GROUP_CLEAN]
ax.bar(np.array(coal_idx)+w/2, sub.iloc[coal_idx]["方案2非负化人均净负担(tCO2/cap)"], w,
       color=C['coal'], edgecolor='white', linewidth=0.5,
       label="With waste heat recovery (coal-heavy grid)")
ax.bar(np.array(clean_idx)+w/2, sub.iloc[clean_idx]["方案2非负化人均净负担(tCO2/cap)"], w,
       color=C['clean'], edgecolor='white', linewidth=0.5,
       label="With waste heat recovery (clean grid)")
ax.set_yscale('log')
ax.set_xticks(x); ax.set_xticklabels([en(c) for c in C9], rotation=90, ha='center', fontsize=10, color='black')
ax.set_ylabel("Per-capita carbon burden (tCO2/cap, log)")
ax.legend(loc='upper right', fontsize=10.5, framealpha=0.45)
ax.grid(axis='y', alpha=0.3, linestyle='--')

# ---------------- (b) Gini time series ----------------
ax = axes[0,1]
tg = df_gini[df_gini["情景"]=="TAS算力转移"].sort_values("年份")
ax.plot(tg["年份"], tg["Gini_人均碳负担(无余热)"], 'o-', color=C['gray'],
        linewidth=2.2, markersize=6, label="Without waste heat recovery")
ax.plot(tg["年份"], tg["Gini_人均净负担_原始(方案2)"], 's--', color=C['coal'],
        linewidth=1.6, markersize=5, label="Raw net burden")
ax.plot(tg["年份"], tg["Gini_人均净负担_非负化(方案2)"], 'D-', color=C['wh'],
        linewidth=2.2, markersize=6, label="Net burden (zero-floored)")
ax.axhline(y=1.0, color='red', linestyle=':', alpha=0.5, linewidth=1)
ax.set_xlabel("Year", fontsize=11); ax.set_ylabel("Gini index", fontsize=11)
ax.legend(loc='center left', fontsize=10.5, framealpha=0.9)
ax.grid(alpha=0.3, linestyle='--'); ax.set_ylim(0.85, 1.65)

# ---------------- (c) Lorenz curve 2035 ----------------
ax = axes[1,0]
subc = df_city[(df_city["情景"]=="TAS算力转移") & (df_city["年份"]==2035)].copy()
subc = subc.set_index("城市").reindex(C9).sort_values("人均碳负担(tCO2/cap)")
pop = subc["人口(万)"].values
burden = subc["人均碳负担(tCO2/cap)"].values*pop
net = subc["方案2非负化人均净负担(tCO2/cap)"].values*pop
cum_pop = np.insert(np.cumsum(pop)/pop.sum(), 0, 0)
cum_b = np.insert(np.cumsum(burden)/burden.sum(), 0, 0)
cum_n = np.insert(np.cumsum(net)/net.sum(), 0, 0)
ax.plot([0,1],[0,1],'--', color=C['diag'], linewidth=1.5, label="Line of equality")
ax.plot(cum_pop, cum_b, '-', color=C['gray'], linewidth=2.0, label="Carbon burden")
ax.plot(cum_pop, cum_n, '-', color=C['wh'], linewidth=2.0, label="Net burden")
# city markers: 9 colored points on the carbon-burden curve (no text labels -> no overlap)
for i, city in enumerate(subc.index):
    ax.scatter(cum_pop[i+1], cum_b[i+1], s=70, color=CITY_COLOR[city],
               marker='o', edgecolor='white', linewidths=0.8, zorder=5)
g = df_gini[(df_gini["情景"]=="TAS算力转移") & (df_gini["年份"]==2035)].iloc[0]
ax.text(0.02, 0.52, f"Gini (burden) = {g['Gini_人均碳负担(无余热)']:.3f}\n"
                    f"Gini (net, zero-floored) = {g['Gini_人均净负担_非负化(方案2)']:.3f}",
        fontsize=10, va='top', bbox=dict(boxstyle='round,pad=0.35', facecolor='white', edgecolor='#999'))
ax.set_xlabel("Cumulative population share", fontsize=11)
ax.set_ylabel("Cumulative carbon burden share", fontsize=11)
city_handles = [plt.Line2D([0],[0], marker='o', color='none', markerfacecolor=CITY_COLOR[c],
                            markersize=8, label=en(c)) for c in CITY_ASC]
leg_city = ax.legend(handles=city_handles, loc='upper left', ncol=3,
                     fontsize=10, framealpha=0.9)
ax.add_artist(leg_city)
ax.legend(loc='center', bbox_to_anchor=(0.62, 0.35), fontsize=10.5, framealpha=0.9)
ax.set_xlim(-0.02,1.02); ax.set_ylim(-0.02,1.02); ax.grid(alpha=0.3, linestyle='--')

# ---------------- (d) Theil decomposition ----------------
ax1 = axes[1,1]
tg2 = df_gini[df_gini["情景"]=="TAS算力转移"].sort_values("年份")
tb = tg2["Theil_组间(煤电vs清洁)"].values; tw = tg2["Theil_组内"].values; yrs = tg2["年份"].values
ax1.bar(yrs, tb, color=C['coal'], edgecolor='white', linewidth=0.5, label="Between (coal-heavy vs clean grid)")
ax1.bar(yrs, tw, bottom=tb, color=C['clean_light'], edgecolor='white', linewidth=0.5, label="Within")
ax1.set_xlabel("Year", fontsize=11); ax1.set_ylabel("Theil T index", fontsize=11)
ax2 = ax1.twinx()
ax2.plot(yrs, tg2["组间贡献率(%)"], 'o-', color=C['wh'], linewidth=2, markersize=5, label="Between share")
ax2.set_ylabel("Between share (%)", fontsize=11, color=C['wh']); ax2.tick_params(axis='y', labelcolor=C['wh'])
ax2.set_ylim(45, 65)
h1,l1 = ax1.get_legend_handles_labels(); h2,l2 = ax2.get_legend_handles_labels()
ax1.legend(h1+h2, l1+l2, loc='upper left', fontsize=10, framealpha=0.9)
ax1.grid(axis='y', alpha=0.3, linestyle='--')

plt.tight_layout()
plt.savefig(os.path.join(OUT, "Fig5_inequality_diagnosis.png"), dpi=300, bbox_inches='tight')
plt.close(); print("Fig5 combined saved")

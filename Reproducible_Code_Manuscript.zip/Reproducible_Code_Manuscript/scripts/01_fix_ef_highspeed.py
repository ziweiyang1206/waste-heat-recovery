# -*- coding: utf-8 -*-
"""统一北上广深电网因子到高速发展情景（表2区间下限），与9承接城口径一致
表2来源：《中国区域电网碳排放因子研究2023》PDF第28页
注：表中()内"上限和下限分别代表新能源高速发展情景和新能源政策发展情景"
即 下限 = 新能源高速发展情景（9承接城已用此口径）
"""
import csv

CSV = r"D:\杨紫薇\第五篇-算力转移导致的水能碳足迹流动\投稿\数据、代码及图源文件\数据汇总\九大城市2026-2035电网碳排放因子_线性插值.csv"

# 表2区间下限值（高速发展情景）= 9承接城已用口径
ANCHOR_LO = {
    "Beijing":   {2025: 0.573, 2030: 0.476, 2035: 0.208},   # (0.573-0.612)(0.476-0.532)(0.208-0.299)
    "Shanghai":  {2025: 0.321, 2030: 0.312, 2035: 0.259},   # (0.321-0.464)(0.312-0.432)(0.259-0.349)
    "Guangzhou": {2025: 0.359, 2030: 0.318, 2035: 0.269},   # 广东 (0.359-0.382)(0.318-0.351)(0.269-0.295)
    "Shenzhen":  {2025: 0.359, 2030: 0.318, 2035: 0.269},
}

def interp(anchors, year):
    ys = sorted(anchors)
    for a, b in zip(ys, ys[1:]):
        if a <= year <= b:
            w = (year - a) / (b - a)
            return round(anchors[a] + w * (anchors[b] - anchors[a]), 3)
    return anchors[ys[-1]] if year > ys[-1] else anchors[ys[0]]

rows = []
with open(CSV, encoding="utf-8-sig") as f:
    reader = csv.reader(f)
    header = next(reader)
    for r in reader:
        rows.append(r)

changed = []
for r in rows:
    city, year = r[0], int(r[2])
    if city in ANCHOR_LO:
        old = float(r[3])
        new = interp(ANCHOR_LO[city], year)
        if abs(old - new) > 1e-9:
            changed.append((city, year, old, new))
        r[3] = str(new)

with open(CSV, "w", encoding="utf-8-sig", newline="") as f:
    w = csv.writer(f)
    w.writerow(header)
    w.writerows(rows)

print(f"== 统一到高速情景下限：修改 {len(changed)} 行 ==")
for c in changed:
    print(f"  {c[0]} {c[1]}: {c[2]} -> {c[3]}")

# 验证：打印北上广深2026/2030/2035
print("\n== 修正后锚点验证（应=表2下限）==")
for city in ["Beijing","Shanghai","Guangzhou","Shenzhen"]:
    vals = {int(r[2]): r[3] for r in rows if r[0]==city and int(r[2]) in [2026,2030,2035]}
    print(f"  {city}: 2026={vals.get(2026)} 2030={vals.get(2030)} 2035={vals.get(2035)}")

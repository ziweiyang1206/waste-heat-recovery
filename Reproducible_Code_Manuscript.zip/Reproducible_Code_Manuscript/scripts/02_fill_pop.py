# -*- coding: utf-8 -*-
import pandas as pd
import openpyxl
from openpyxl.styles import PatternFill, Font

BASE = r"D:/杨紫薇/第五篇-算力转移导致的水能碳足迹流动/投稿/数据、代码及图源文件"
POPX = BASE + r"\数据汇总\298个地级市人口密度1998-2024年无缺失.xlsx"
GDPX = BASE + r"\数据汇总\2000-2024地级市GDP相关指标.xlsx"
WB   = BASE + r"\13城市人口GDP历史数据收集清单.xlsx"

CITIES = ["北京","上海","广州","深圳","成都","重庆","张家口","芜湖","韶关","呼和浩特","贵阳","庆阳","中卫"]
ROW_OF = {y: y - 2005 + 4 for y in range(2005, 2026)}   # 行4=2005
COL_OF = {c: i + 2 for i, c in enumerate(CITIES)}        # 列2=北京

YELLOW = PatternFill("solid", fgColor="FFF9E79F")

# ---- 读人口密度表 ----
pdf_ = pd.read_excel(POPX, sheet_name="面板数据")
pdf_.columns = [str(c).strip() for c in pdf_.columns]
pdf_["key"] = pdf_["城市"].astype(str).str.strip().str.replace("市","",regex=False)
pop = "常住人口（万人）"
sub = pdf_[pdf_["key"].isin(CITIES)]
piv = sub.pivot_table(index="年份", columns="key", values=pop, aggfunc="first")

# ---- 读GDP文件（原值版）----
gdf = pd.read_excel(GDPX, sheet_name="2000-2024")
gdf.columns = [str(c).strip() for c in gdf.columns]
gdf["key"] = gdf["城市"].astype(str).str.strip().str.replace("市","",regex=False)
gsub = gdf[gdf["key"].isin(CITIES)]
gpiv = gsub.pivot_table(index="年份", columns="key", values="GDP(万元)", aggfunc="first") / 1e4  # 万元→亿元

wb = openpyxl.load_workbook(WB)
wsp = wb["人口数据填写模板"]
wsg = wb["GDP数据填写模板"]

# ---- 人口填充 ----
filled, warn20 = [], []
for c in CITIES:
    col = COL_OF[c]
    for y in range(2005, 2025):
        r = ROW_OF[y]
        cur = wsp.cell(row=r, column=col).value
        newv = piv.loc[y, c] if y in piv.index and pd.notna(piv.loc[y, c]) else None
        if y >= 2010 and y <= 2019:
            if newv is not None and cur is None:
                cell = wsp.cell(row=r, column=col, value=round(float(newv), 1))
                cell.fill = YELLOW
                filled.append((c, y, round(float(newv),1)))
        elif y >= 2005 and y <= 2009:
            if newv is not None and cur is None:
                cell = wsp.cell(row=r, column=col, value=round(float(newv), 1))
                cell.fill = YELLOW
                filled.append((c, y, round(float(newv),1), "2005-2009选填区"))
        elif y >= 2020:
            if newv is not None and cur is not None and abs(float(cur) - float(newv)) > 5:
                warn20.append((c, y, cur, round(float(newv),1)))

# ---- GDP交叉核对 ----
gwarn = []
for c in CITIES:
    col = COL_OF[c]
    for y in range(2005, 2025):
        r = ROW_OF[y]
        cur = wsg.cell(row=r, column=col).value
        if y in gpiv.index and pd.notna(gpiv.loc[y, c]) and cur is not None:
            g = gpiv.loc[y, c]
            if abs(float(cur) - g) / max(g, 1) > 0.02:  # >2%差异
                gwarn.append((c, y, round(float(cur),1), round(g,1)))

wb.save(WB)
print(f"人口新填 {len(filled)} 格")
print("2020-2024 与密度表差异>5万的城市-年份:", warn20 if warn20 else "无")
print(f"\nGDP与《2000-2024地级市GDP相关指标》差异>2%的: {len(gwarn)}项")
for x in gwarn[:25]:
    print("  ", x)

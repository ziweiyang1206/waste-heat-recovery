# -*- coding: utf-8 -*-
"""
13_fig7_combined.py — Fig.7 Distributional welfare analysis of waste heat recovery.
a: DCEA concentration curves (benefit=blue, cost=red)
b: Per-capita net welfare (recovery benefit minus carbon burden) at 70 yuan/t,
   by city and income group.
Both subplots: no titles.
"""
import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib as mpl
from matplotlib.patches import Patch

mpl.rcParams['font.family'] = 'Arial'
mpl.rcParams['font.size'] = 12
mpl.rcParams['axes.linewidth'] = 1.0
mpl.rcParams['figure.dpi'] = 100
mpl.rcParams['savefig.dpi'] = 300
mpl.rcParams['savefig.bbox'] = 'tight'

BLUE = '#2C6FB0'; RED = '#E74C3C'; GRAY = '#95A5A6'; DIAG = '#7F8C8D'
CN2EN = {'成都':'Chengdu','重庆':'Chongqing','贵阳':'Guiyang','韶关':'Shaoguan',
         '芜湖':'Wuhu','呼和浩特':'Hohhot','庆阳':'Qingyang','张家口':'Zhangjiakou',
         '中卫':'Zhongwei'}
def en(c): return CN2EN.get(c, c)

BASE = r"D:\杨紫薇\第五篇-算力转移导致的水能碳足迹流动\投稿\数据、代码及图源文件"
GINI = BASE + r"\碳不平等测算_Gini_Theil.xlsx"
OUT = BASE + r"\实验过程"
P = 70

df = pd.read_excel(GINI, sheet_name="9城碳负担与人均GDP")
sub = df[(df["情景"]=="TAS算力转移") & (df["年份"]==2035)].copy()
sub["gdp_pc"] = sub["GDP(亿元)"]*1e8 / (sub["人口(万)"]*1e4)
sub = sub.sort_values("gdp_pc").reset_index(drop=True)
n = len(sub)
pop = sub["人口(万)"].values
w = pop/pop.sum(); R = np.cumsum(w) - w/2
burden_mt = sub["碳负担(Mt)"].values
wh_mt = sub["方案2减排"].values
net_mt = wh_mt - burden_mt

def c_weighted(y, w, R):
    mu = np.sum(w*y)
    return np.nan if abs(mu)<1e-12 else (2.0/mu)*np.sum(w*(y-mu)*(R-0.5))
Cb_w = c_weighted(wh_mt, w, R); Cc_w = c_weighted(burden_mt, w, R)

fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(13, 5.5))

# ---------------- (a) DCEA concentration curves ----------------
benefit_yuan = wh_mt*1e6*P; cost_yuan = burden_mt*1e6*P
cum_pop = np.insert(np.cumsum(w), 0, 0)
cum_b = np.insert(np.cumsum(benefit_yuan)/benefit_yuan.sum(), 0, 0)
cum_c = np.insert(np.cumsum(cost_yuan)/cost_yuan.sum(), 0, 0)
ax1.plot([0,1],[0,1],'--', color=DIAG, linewidth=1.5, label="Line of equality")
ax1.plot(cum_pop, cum_b, 'o-', color=BLUE, linewidth=2.2, markersize=7,
         label="Benefit (waste heat recovery)")
ax1.plot(cum_pop, cum_c, 's-', color=RED, linewidth=2.2, markersize=7,
         label="Cost (carbon burden)")
OFFSET7 = {"张家口":(-22,10), "韶关":(20,12), "呼和浩特":(-72,0), "芜湖":(6,4)}
for i, row in sub.iterrows():
    ax1.annotate(en(row["城市"]), (cum_pop[i+1], cum_c[i+1]),
                 textcoords="offset points", xytext=OFFSET7.get(row["城市"], (7,5)),
                 fontsize=9, color='#444')
ax1.text(0.56, 0.78, f"C_benefit = {Cb_w:+.3f}\nC_cost = {Cc_w:+.3f}\n(population-weighted)",
         fontsize=10, bbox=dict(boxstyle='round,pad=0.35', facecolor='white', edgecolor='#999'))
ax1.set_xlabel("Cumulative population share (ranked by per-capita GDP, poor -> rich)", fontsize=11)
ax1.set_ylabel("Cumulative share", fontsize=11)
ax1.legend(loc='upper left', fontsize=9.5, framealpha=0.9)
ax1.grid(alpha=0.3, linestyle='--'); ax1.set_xlim(-0.02,1.02); ax1.set_ylim(-0.02,1.02)

# ---------------- (b) per-capita net welfare at 70 yuan/t ----------------
x = np.arange(n)
nb = net_mt*1e6*P/(pop*1e4)
bar_colors = [BLUE if v>=0 else RED for v in nb]
groups = ["Low" if i<3 else "Mid" if i<6 else "High" for i in range(n)]
gbg = {'Low':'#FDEBD0', 'Mid':'#D6EAF8', 'High':'#EAECEE'}
for i in range(n):
    g = groups[i]
    ax2.axvspan(i-0.5, i+0.5, color=gbg[g], zorder=0)
ax2.bar(x, nb, color=bar_colors, edgecolor='white', linewidth=0.8, width=0.66, zorder=3)
ax2.axhline(0, color='#333', linewidth=0.8)
ax2.set_xticks(x)
ax2.set_xticklabels([en(c) for c in sub["城市"]], rotation=90, ha='center', fontsize=10)
ax2.set_ylabel("Per-capita net welfare (yuan/cap)", fontsize=11)
ax2.set_xlabel("Income group: low | middle | high (ranked by per-capita GDP)", fontsize=11)
for i, g in enumerate(groups):
    ax2.text(i, nb[i] + (0.5 if nb[i]>=0 else -0.5), f"{nb[i]:+.1f}",
             ha='center', va='bottom' if nb[i]>=0 else 'top', fontsize=8.5, color='#333')
ax2.legend(handles=[Patch(color=BLUE, label="Net gain"),
                    Patch(color=RED, label="Net loss")],
           loc='lower right', fontsize=10, framealpha=0.9)
ax2.grid(axis='y', alpha=0.3, linestyle='--')

plt.tight_layout()
plt.savefig(os.path.join(OUT, "Fig7_distributional_welfare.png"), dpi=300, bbox_inches='tight')
plt.close(); print("Fig7 combined saved")

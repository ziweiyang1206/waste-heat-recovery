# -*- coding: utf-8 -*-
"""
07_DCEA.py  (revised: population-weighted concentration index)
================================================================
Distributional Cost-Effectiveness Analysis (DCEA):
  1. Monetize net benefit = (WH reduction - carbon burden) x carbon price
  2. Rank 9 receiving cities by per-capita GDP (poor -> rich)
  3. Concentration index C (population-weighted, standard DCEA)
     C > 0 pro-rich (regressive); C < 0 pro-poor (progressive)
  4. Concentration curves (benefit & cost) + per-capita net benefit bar chart

Revision notes:
  - C index now population-weighted: C = (2/mu)*sum(w_i*(y_i-mu)*(R_i-0.5))
    w_i = pop share, R_i = cumulative pop share to midpoint.
    Previous equal-weight version (r=(i+0.5)/n) was inconsistent with the
    population-weighted concentration curve x-axis. Both calibers are reported.
  - benefit/cost (non-negative) use population-weighted C as main indicator.
  - net (contains negatives) reported raw (may exceed [-1,1]) AND non-negativized.
  - Per-capita net benefit: Zhongwei is the largest per-capita loss center
    (-190.71 Yuan/cap @70), Hohhot is the largest total loss center (-6.257 Mt).
"""

import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib as mpl
from matplotlib.patches import Patch

# ============================ Global style (Arial 12pt) ============================
mpl.rcParams['font.family'] = 'Arial'
mpl.rcParams['font.size'] = 12
mpl.rcParams['axes.linewidth'] = 1.0
mpl.rcParams['figure.dpi'] = 100
mpl.rcParams['savefig.dpi'] = 300
mpl.rcParams['savefig.bbox'] = 'tight'

COLOR = {
    'coal': '#E74C3C', 'clean': '#3498DB',
    'wh': '#E67E22', 'no_wh': '#2C3E50',
    'diag': '#7F8C8D',
}

CN2EN = {'成都':'Chengdu','重庆':'Chongqing','贵阳':'Guiyang','韶关':'Shaoguan',
         '芜湖':'Wuhu','呼和浩特':'Hohhot','庆阳':'Qingyang','张家口':'Zhangjiakou',
         '中卫':'Zhongwei'}
def en(c): return CN2EN.get(c, c)

BASE = r"D:\杨紫薇\第五篇-算力转移导致的水能碳足迹流动\投稿\数据、代码及图源文件"
GINI = BASE + r"\碳不平等测算_Gini_Theil.xlsx"
OUT = BASE + r"\实验过程"
os.makedirs(OUT, exist_ok=True)
PRICES = [50, 70, 100]

# ============================ Read 9-city 2035 TAS ============================
df = pd.read_excel(GINI, sheet_name="9城碳负担与人均GDP")
sub = df[(df["情景"]=="TAS算力转移") & (df["年份"]==2035)].copy()
sub["gdp_pc"] = sub["GDP(亿元)"]*1e8 / (sub["人口(万)"]*1e4)
sub = sub.sort_values("gdp_pc").reset_index(drop=True)

n = len(sub)
pop = sub["人口(万)"].values
w = pop / pop.sum()                       # population weights
R = np.cumsum(w) - w/2                    # cumulative pop share to midpoint (0,1)
r_eq = (np.arange(n) + 0.5) / n           # equal-weight rank (for comparison)

burden_mt = sub["碳负担(Mt)"].values
wh_mt     = sub["方案2减排"].values
net_mt    = wh_mt - burden_mt

# ============================ Concentration index ============================
def c_weighted(y, w, R):
    """Population-weighted concentration index (standard DCEA).
    y should be non-negative for standard interpretation."""
    mu = np.sum(w * y)
    if abs(mu) < 1e-12: return np.nan
    return (2.0/mu) * np.sum(w * (y - mu) * (R - 0.5))

def c_equal(y, r):
    """Equal-weight (rank-based) C, reported for comparison only."""
    mu = np.mean(y)
    if abs(mu) < 1e-12: return np.nan
    return 2.0 * np.sum((y - mu) * (r - 0.5)) / (len(y) * mu)

# Main: population-weighted
Cb_w = c_weighted(wh_mt, w, R)
Cc_w = c_weighted(burden_mt, w, R)
Cn_w_raw = c_weighted(net_mt, w, R)                   # raw, may exceed [-1,1]
Cn_w_nn  = c_weighted(np.maximum(net_mt, 0), w, R)    # non-negativized

# Comparison: equal-weight
Cb_e = c_equal(wh_mt, r_eq)
Cc_e = c_equal(burden_mt, r_eq)
Cn_e = c_equal(net_mt, r_eq)

print("9 cities ranked by per-capita GDP (poor -> rich):")
print(sub[["城市","gdp_pc","人口(万)","碳负担(Mt)","方案2减排"]].assign(City=sub["城市"].map(en)).to_string(index=False))
print("\n== Concentration index ==")
print(f"  C_benefit : equal={Cb_e:+.4f}  pop-weighted={Cb_w:+.4f}")
print(f"  C_cost    : equal={Cc_e:+.4f}  pop-weighted={Cc_w:+.4f}")
print(f"  C_net(raw): equal={Cn_e:+.4f}  pop-weighted={Cn_w_raw:+.4f}  (may exceed [-1,1])")
print(f"  C_net(nn) :                 pop-weighted={Cn_w_nn:+.4f}")

# ============================ Fig 7: concentration curves (population-weighted) ============================
P = 70
benefit_yuan = wh_mt * 1e6 * P
cost_yuan    = burden_mt * 1e6 * P
cum_pop = np.insert(np.cumsum(w), 0, 0)
cum_b   = np.insert(np.cumsum(benefit_yuan)/benefit_yuan.sum(), 0, 0)
cum_c   = np.insert(np.cumsum(cost_yuan)/cost_yuan.sum(), 0, 0)

fig, ax = plt.subplots(figsize=(7.8, 6.6))
ax.plot([0,1],[0,1],'--', color=COLOR['diag'], linewidth=1.5, label="Line of equality")
ax.plot(cum_pop, cum_b, 'o-', color=COLOR['wh'], linewidth=2.2, markersize=7, label="Benefit (WH)")
ax.plot(cum_pop, cum_c, 's-', color=COLOR['coal'], linewidth=2.2, markersize=7, label="Cost (burden)")
OFFSET7 = {"张家口":(-22,10), "韶关":(8,-14), "呼和浩特":(-72,0), "芜湖":(6,4)}
for i, row in sub.iterrows():
    ax.annotate(en(row["城市"]), (cum_pop[i+1], cum_c[i+1]),
                textcoords="offset points", xytext=OFFSET7.get(row["城市"], (7, 5)),
                fontsize=10, color='#555')
ax.text(0.13, 0.74, f"C_benefit = {Cb_w:+.3f}\nC_cost = {Cc_w:+.3f}\n(population-weighted)",
        fontsize=11, bbox=dict(boxstyle='round,pad=0.4', facecolor='#FEF9E7', edgecolor='#F39C12'))
ax.set_xlabel("Cumulative population share (ranked by per-capita GDP, poor -> rich)", fontsize=12)
ax.set_ylabel("Cumulative share", fontsize=12)
ax.set_title("Fig 7  DCEA Concentration Curve (2035, TAS)", fontsize=12.5, fontweight='bold')
ax.legend(loc='upper left', fontsize=11)
ax.grid(alpha=0.3, linestyle='--')
ax.set_xlim(-0.02, 1.02); ax.set_ylim(-0.02, 1.02)
plt.savefig(os.path.join(OUT, "Fig7_concentration_curve.png"), dpi=300, bbox_inches='tight')
plt.close(); print("\nFig7 done")

# ============================ Fig 8: per-capita net benefit by city (3 prices) ============================
fig, ax = plt.subplots(figsize=(10, 5.5))
x = np.arange(n); wbar = 0.27
for i, P in enumerate(PRICES):
    nb = net_mt * 1e6 * P / (pop * 1e4)
    colors = [COLOR['clean'] if v >= 0 else COLOR['coal'] for v in nb]
    ax.bar(x + (i-1)*wbar, nb, wbar, label=f"Price = {P} Yuan/t",
           color=colors, alpha=0.55 + 0.15*i, edgecolor='white', linewidth=0.5)
ax.axhline(0, color='#333', linewidth=0.8)
ax.set_xticks(x)
ax.set_xticklabels([en(c) for c in sub["城市"]], rotation=40, ha='right')
ax.set_ylabel("Per-capita net benefit (Yuan/capita)", fontsize=12)
ax.set_title("Fig 8  Per-capita Net Benefit by City, Ranked by Income (2035, TAS)",
             fontsize=12.5, fontweight='bold')
ax.legend(fontsize=11, framealpha=0.9)
ax.grid(axis='y', alpha=0.3, linestyle='--')
plt.savefig(os.path.join(OUT, "Fig8_net_benefit_by_city.png"), dpi=300, bbox_inches='tight')
plt.close(); print("Fig8 done")

# ============================ Export DCEA results to Excel ============================
sub["City"] = sub["城市"].map(en)
sub["Income group"] = ["Low" if i<3 else "Mid" if i<6 else "High" for i in range(n)]

detail = pd.DataFrame({
    "City": sub["City"],
    "Income group": sub["Income group"],
    "GDP per capita (Yuan)": sub["gdp_pc"].round(0),
    "Population (10k)": sub["人口(万)"],
    "Burden (Mt)": burden_mt.round(3),
    "WH reduction (Mt)": wh_mt.round(3),
})
for P in PRICES:
    detail[f"Net @ {P} Yuan/t (Yuan/cap)"] = (net_mt * 1e6 * P / (pop * 1e4)).round(2)

# Group summary
grp_rows = []
for g in ["Low","Mid","High"]:
    s = sub[sub["Income group"]==g]
    row = {"Income group":g,
           "Cities":", ".join(s["City"]),
           "Population (10k)":s["人口(万)"].sum()}
    for P in PRICES:
        net_total = (s["方案2减排"].sum() - s["碳负担(Mt)"].sum()) * 1e6 * P
        row[f"Net @ {P} Yuan/t (Yuan/cap)"] = round(net_total / (s["人口(万)"].sum() * 1e4), 2)
    grp_rows.append(row)
df_grp = pd.DataFrame(grp_rows)

# C index: dual caliber
df_c = pd.DataFrame({
    "Indicator": ["C_benefit (WH reduction)", "C_cost (carbon burden)",
                  "C_net (raw, with negatives)", "C_net (zero-floored)"],
    "Equal-weight": [round(Cb_e,4), round(Cc_e,4), round(Cn_e,4),
                     round(c_equal(np.maximum(net_mt,0), r_eq),4)],
    "Population-weighted (standard)": [round(Cb_w,4), round(Cc_w,4), round(Cn_w_raw,4), round(Cn_w_nn,4)],
    "Interpretation": [
        "pro-poor (<0) / pro-rich (>0)" ,
        "pro-poor (<0) / pro-rich (>0)",
        "unstable if exceeds [-1,1] due to negatives; use group table as main",
        "robust; net benefit concentrated among richer (>0) or poorer (<0) cities",
    ],
})

# ============================ WHR abatement cost (water-source heat pump, sourced cases) ============================
# NOTE: This is WHR EQUIPMENT cost (heat pump +管网 + controls), NOT liquid-cooling retrofit cost.
# Liquid cooling (PUE reduction) is a separate散热 technology; WHR = waste heat RECOVERY for heating.
df_abate = pd.DataFrame([{
    "Technology": "Water-source heat pump WHR (水源热泵余热回收)",
    "Primary case": "Gansu Telecom Hub (甘肃电信二枢纽水源热泵项目)",
    "Primary case source": "Lanzhou Municipal Bureau of Industry & IT (兰州市工业和信息化局), 2026",
    "Primary case URL": "https://gxj.lanzhou.gov.cn/art/2026/10/10/art_23768_1744698.html",
    "Primary case reduction (tCO2/yr)": 665.69,
    "Primary case description": "2 water-source heat pump units, 45-55C hot water from server waste heat, replacing municipal heating; northwest China telecom-data hub",
    "Corroborating case 1": "China Mobile Hohhot DC (呼和浩特, matches paper 9-city scope)",
    "Corroborating case 1 source": "Toutiao report citing China Mobile Inner Mongolia, 2025",
    "Corroborating case 1 reduction (tCO2/yr)": 5500,
    "Corroborating case 1 savings (10k RMB/yr)": "200-500",
    "Corroborating case 2": "GDS Beijing Hengchang DC (万国数据恒长, Beijing first DC WHR project)",
    "Corroborating case 2 source": "China Daily (中国日报网), 2025",
    "Corroborating case 2 reduction (tCO2/yr)": 166.6,
    "Investment benchmark source": "China Heat Pump Association (中国节能协会热泵专委会), 2026 case compilation, 47 projects",
    "Investment per MW (10k RMB)": "380-550 (heat pump主机 +管网 + controls)",
    "Annual heat supply per MW (GJ)": 48000,
    "Annual heat pump electricity per MW (10k kWh)": 150,
    "Annual heating revenue per MW (10k RMB)": 192,
    "Gross CO2 reduction per MW (tCO2/yr)": 5134,   # coal displacement: 48000 GJ / (29.27 GJ/t * 0.85) * 2.66 tCO2/tce
    "Heat pump electricity emissions per MW (tCO2/yr)": 750,  # 150万kWh * 0.5 kgCO2/kWh
    "Net CO2 reduction per MW (tCO2/yr)": 4384,
    "Gross abatement cost (RMB/tCO2)": "~276 (equipment annualized 15yr + operating, before heating revenue)",
    "Net abatement cost (RMB/tCO2)": "~-162 (net benefit: heating revenue exceeds equipment + operating)",
    "Payback period (years)": "3-5 (median), 2.1-6.8 (range of 47 projects)",
    "Carbon price benchmark (RMB/tCO2)": 70,
    "Gross cost / carbon price ratio": "~4x",
    "Critical distinction": "This is WHR equipment cost (heat pump +管网), NOT liquid-cooling retrofit; liquid cooling reduces PUE (saves electricity), WHR recovers waste heat (displaces fossil heating) — different technologies, different cost structures",
    "Policy interpretation": "WHR is private-benefit-dominated: heating revenue exceeds equipment + operating cost (net negative abatement cost); carbon reduction accrues as externality; deployment driven by heating savings not carbon price; payback 3-5yr (longer than liquid cooling ~1yr because WHR displaces cheaper coal-heat, not expensive electricity)",
}])

out_xlsx = os.path.join(OUT, "DCEA_results.xlsx")
with pd.ExcelWriter(out_xlsx, engine="openpyxl") as w:
    detail.to_excel(w, sheet_name="city_detail", index=False)
    df_grp.to_excel(w, sheet_name="group_summary", index=False)
    df_c.to_excel(w, sheet_name="c_index", index=False)
    df_abate.to_excel(w, sheet_name="abatement_cost", index=False)
print(f"\nDCEA results saved to: {out_xlsx}")
print("\n== Group summary (Yuan/capita) ==")
print(df_grp.to_string(index=False))
print("\n== C index (dual caliber) ==")
print(df_c.to_string(index=False))

# -*- coding: utf-8 -*-
"""碳不平等测算：Gini/Theil指数 + 负担-受益-缓解三层框架
9承接城主结果（BS=S1 vs TAS=S2，方案1/2/3，煤电vs清洁电网分组）+ 13城净负担补充
"""
import numpy as np
import pandas as pd
import openpyxl
from openpyxl.styles import Font, Alignment, PatternFill, Border, Side

BASE = r"D:\杨紫薇\第五篇-算力转移导致的水能碳足迹流动\投稿\数据、代码及图源文件\数据汇总"
PRED = r"D:\杨紫薇\第五篇-算力转移导致的水能碳足迹流动\投稿\数据、代码及图源文件\13城市人口GDP预测_2005-2035.xlsx"
EFCSV = BASE + r"\九大城市2026-2035电网碳排放因子_线性插值.csv"
OUT  = r"D:\杨紫薇\第五篇-算力转移导致的水能碳足迹流动\投稿\数据、代码及图源文件\碳不平等测算_Gini_Theil.xlsx"

# 9承接城英文→中文
T9 = {"Chengdu":"成都","Chongqing":"重庆","Guiyang":"贵阳","Hohhot":"呼和浩特",
      "Qingyang":"庆阳","Shaoguan":"韶关","Wuhu":"芜湖","Zhangjiakou":"张家口","Zhongwei":"中卫"}
C9 = list(T9.values())  # 中文
# 13城（9承接+4源）
SRC4 = ["北京","上海","广州","深圳"]
C13 = C9 + SRC4
# 英文→中文映射（用于读EF CSV和转移明细CSV）
EN2CN = T9.copy()  # {"Chengdu":"成都",...} 英文键→中文值
EN2CN.update({"Beijing":"北京","Shanghai":"上海","Guangzhou":"广州","Shenzhen":"深圳"})
CN2EN = {v:k for k,v in EN2CN.items()}  # 中文→英文

# 分组：煤电高EF vs 清洁低EF（以2026 EF=0.4为界）
GROUP9 = {"呼和浩特":"煤电高EF","张家口":"煤电高EF","芜湖":"煤电高EF","庆阳":"煤电高EF","中卫":"煤电高EF",
          "成都":"清洁低EF","重庆":"清洁低EF","贵阳":"清洁低EF","韶关":"清洁低EF"}
YEARS = list(range(2026, 2036))
# ---------- 读负担侧（9城×10年×S1/S2）----------
bur = pd.read_excel(BASE + r"\情景一+情景二_总转移碳排放.xlsx")
bur["城市"] = bur["城市"].map(T9)
bur = bur[bur["城市"].notna()][["年份","城市","emission factor (kgCO2/kWh)","S1_Total_Carbon (Mt)","S2_Total_Carbon (Mt)"]]
bur = bur.sort_values(["年份","城市"]).reset_index(drop=True)

# ---------- 读受益侧（9城×10年×方案×三路径）----------
def read_benefit(scn):
    f = BASE + (r"\情景一_年份+城市_三路径碳减排量_明细总表.xlsx" if scn=="S1" else r"\情景二_年份+城市_三路径碳减排量_明细总表.xlsx")
    df = pd.read_excel(f)
    df["城市"] = df["城市名称"].map(T9)
    df = df[df["城市"].notna()]
    for plan in [1,2,3]:
        df[f"方案{plan}_总减排"] = df[f"方案{plan}_供暖_碳减排量(Mt)"] + df[f"方案{plan}_制冷_碳减排量(Mt)"] + df[f"方案{plan}_供电_碳减排量(Mt)"]
    col_scn = "S1_Total_Carbon (Mt)" if scn=="S1" else "S2_Total_Carbon (Mt)"
    return df[["年份","城市",f"方案1_总减排",f"方案2_总减排",f"方案3_总减排", col_scn]].rename(columns={col_scn:"总转移碳"})

ben_S1 = read_benefit("S1")
ben_S2 = read_benefit("S2")

# ---------- 读预测人口/GDP（中情景GDP）----------
wb_p = openpyxl.load_workbook(PRED)
ws_pop = wb_p["人口预测_2005-2035"]
ws_gdp = wb_p["GDP_中情景"]
COL_C9 = {}  # 中文城市→列号（从预测Excel表头读取真实列顺序）
for j in range(1, ws_pop.max_column + 1):
    h = ws_pop.cell(row=1, column=j).value
    if h in C13:
        COL_C9[h] = j
# 预测Excel：表头行1，数据从行2开始（行2=2005，行23=2026...行32=2035）
ROW_Y = {y: y - 2005 + 2 for y in range(2005, 2036)}  # 行2=2005
pop_pred, gdp_pred = {}, {}
for c in C13:
    if c not in COL_C9:
        print(f"WARNING: {c} 不在预测Excel表头中")
        continue
    pop_pred[c] = [ws_pop.cell(row=ROW_Y[y], column=COL_C9[c]).value for y in YEARS]
    gdp_pred[c] = [ws_gdp.cell(row=ROW_Y[y], column=COL_C9[c]).value for y in YEARS]

# ---------- 读EF（13城，用于源城市反事实）----------
ef = pd.read_csv(EFCSV, encoding="utf-8-sig")
ef["城市中文"] = ef["城市"].map(EN2CN)
ef_pivot = ef.pivot_table(index="年份", columns="城市中文", values="电网碳排放因子", aggfunc="first")
print("EF表城市列:", list(ef_pivot.columns))

# ============================================================
# 第一层：9城碳负担分配（人均/单位GDP）
# ============================================================
def gini(x, w=None):
    """人口加权Gini（w=None时等权）。可处理负值，要求加权均值μ≠0。
    口径：按x升序排列，w_i=人口份额，R_i=累计人口份额到中点。
    G=(2/μ)·Σw_i·(x_i−μ)·(R_i−0.5)。与07_DCEA.c_weighted同口径（排序按x本身时C=Gini）。"""
    x = np.asarray(x, dtype=float)
    n = len(x)
    if n == 0: return None
    if w is None:
        w = np.ones(n)/n
    w = np.asarray(w, dtype=float)
    w = w/w.sum()
    mu = np.sum(w*x)
    if abs(mu) < 1e-15: return None
    order = np.argsort(x)
    xs, ws = x[order], w[order]
    R = np.cumsum(ws) - ws/2
    return float((2.0/mu) * np.sum(ws * (xs - mu) * (R - 0.5)))

def theil(x, w=None):
    """人口加权Theil T指数（w=None时等权）。含负值时用加权相对均值绝对偏差作稳健替代。"""
    x = np.asarray(x, dtype=float)
    n = len(x)
    if n == 0: return None
    if w is None:
        w = np.ones(n)/n
    w = np.asarray(w, dtype=float)
    w = w/w.sum()
    mu = np.sum(w*x)
    if abs(mu) < 1e-15: return None
    pos = x[x > 0]
    if len(pos) == n:
        return float(np.sum(w * (x/mu) * np.log(x/mu)))
    return float(np.sum(w * np.abs(x-mu))/abs(mu))  # 含负值：加权相对均值绝对偏差

def theil_decomp(x, groups, w=None):
    """人口加权Theil组间/组内分解（w=None时等权，要求全正）。"""
    x = np.asarray(x, dtype=float); groups = np.asarray(groups)
    n = len(x)
    if w is None:
        w = np.ones(n)/n
    w = np.asarray(w, dtype=float)
    w = w/w.sum()
    mu = np.sum(w*x)
    if abs(mu) < 1e-15 or (x<=0).any(): return None, None, None
    T_total = np.sum(w * (x/mu) * np.log(x/mu))
    T_between = 0
    for g in np.unique(groups):
        mask = groups==g
        wg = w[mask]; xg = x[mask]
        Wg = wg.sum()           # 组人口份额
        mug = np.sum(wg*xg)/Wg  # 组加权均值
        T_between += Wg * (mug/mu) * np.log(mug/mu)
    T_within = T_total - T_between
    return float(T_total), float(T_between), float(T_within)

# 构建测算面板
rows1 = []
for scn, label in [("S1","BS基准"),("S2","TAS算力转移")]:
    ben = ben_S1 if scn=="S1" else ben_S2
    for y in YEARS:
        for c in C9:
            b = bur[(bur["年份"]==y)&(bur["城市"]==c)]
            bt = ben[(ben["年份"]==y)&(ben["城市"]==c)]
            if len(b)==0 or len(bt)==0: continue
            carbon = float(b.iloc[0][f"{scn}_Total_Carbon (Mt)"])
            p1 = float(bt.iloc[0]["方案1_总减排"])
            p2 = float(bt.iloc[0]["方案2_总减排"])
            p3 = float(bt.iloc[0]["方案3_总减排"])
            pop = float(pop_pred[c][YEARS.index(y)])
            gdp = float(gdp_pred[c][YEARS.index(y)])
            rows1.append({"情景":label,"年份":y,"城市":c,"组别":GROUP9[c],
                          "碳负担(Mt)":carbon,"人口(万)":pop,"GDP(亿元)":gdp,
                          "方案1减排":p1,"方案2减排":p2,"方案3减排":p3,
                          "人均碳负担(tCO2/cap)":carbon*1e6/(pop*1e4),  # Mt→t, 万人→人
                          "单位GDP碳负担(tCO2/万元)":carbon*1e6/(gdp*1e4),  # Mt→t, 亿元→万元
                          "方案2净负担(Mt)":carbon-p2,
                          "方案2人均净负担(tCO2/cap)":(carbon-p2)*1e6/(pop*1e4),
                          "方案2非负化净负担(Mt)":max(carbon-p2, 0),
                          "方案2非负化人均净负担(tCO2/cap)":max((carbon-p2)*1e6/(pop*1e4), 0)})
df1 = pd.DataFrame(rows1)

# ============================================================
# Gini/Theil 指数表
# ============================================================
def indices_for(df_sub, col):
    xs = df_sub[col].values
    gs = df_sub["组别"].values
    ws = df_sub["人口(万)"].values  # 人口权重（人口加权Gini/Theil）
    g = gini(xs, ws)
    tt, tb, tw = theil_decomp(xs, gs, ws) if (xs>0).all() else (None, None, None)
    tt_alt = theil(xs, ws)  # 含负值时的稳健替代
    return g, tt, tb, tw, tt_alt

gini_rows = []
for scn in ["BS基准","TAS算力转移"]:
    for y in YEARS:
        sub = df1[(df1["情景"]==scn)&(df1["年份"]==y)]
        # 无余热：人均碳负担（全正，标准Gini，基准锚）
        g_b, t_b, tb_b, tw_b, _ = indices_for(sub, "人均碳负担(tCO2/cap)")
        # 有余热(方案2)：人均净负担（原始口径，含负值）
        g_n_raw, t_n, tb_n, tw_n, t_alt = indices_for(sub, "方案2人均净负担(tCO2/cap)")
        # 有余热(方案2)：人均净负担（非负化口径，max(净负担,0)，分离机制A）
        g_n_nn, _, _, _, _ = indices_for(sub, "方案2非负化人均净负担(tCO2/cap)")
        # 单位GDP碳负担
        g_gdp, _, _, _, _ = indices_for(sub, "单位GDP碳负担(tCO2/万元)")
        mitigation_raw = (g_b - g_n_raw)/g_b*100 if (g_b and g_n_raw is not None) else None
        mitigation_nn = (g_b - g_n_nn)/g_b*100 if (g_b and g_n_nn is not None) else None
        gini_rows.append({"情景":scn,"年份":y,
                          "Gini_人均碳负担(无余热)":g_b,
                          "Gini_人均净负担_原始(方案2)":g_n_raw,
                          "Gini_人均净负担_非负化(方案2)":g_n_nn,
                          "缓解效应_原始(%)":mitigation_raw,
                          "缓解效应_非负化(%)":mitigation_nn,
                          "Gini_单位GDP碳负担(无余热)":g_gdp,
                          "Theil_人均碳负担":t_b,
                          "Theil_组间(煤电vs清洁)":tb_b,
                          "Theil_组内":tw_b,
                          "Theil_人均净负担(方案2)":t_n if t_n is not None else t_alt,
                          "组间贡献率(%)":(tb_b/t_b*100) if (t_b and tb_b is not None) else None})
df_gini = pd.DataFrame(gini_rows)

# 方案1/3敏感性（含非负化双口径）
sens_rows = []
for scn in ["BS基准","TAS算力转移"]:
    for y in YEARS:
        sub = df1[(df1["情景"]==scn)&(df1["年份"]==y)]
        for plan, pcol in [("方案1","方案1减排"),("方案2","方案2减排"),("方案3","方案3减排")]:
            net = sub["碳负担(Mt)"].values - sub[pcol].values
            pop = sub["人口(万)"].values
            per_net_raw = net*1e6/(pop*1e4)
            per_net_nn = np.maximum(per_net_raw, 0)
            g_raw = gini(per_net_raw, pop)   # 人口加权
            g_nn = gini(per_net_nn, pop)     # 人口加权
            g0 = gini(sub["人均碳负担(tCO2/cap)"].values, pop)  # 人口加权
            sens_rows.append({"情景":scn,"年份":y,"余热方案":plan,
                              "Gini_人均净负担_原始":g_raw,
                              "Gini_人均净负担_非负化":g_nn,
                              "Gini_人均碳负担(无余热)":g0,
                              "缓解效应_原始(%)":(g0-g_raw)/g0*100 if (g0 and g_raw) else None,
                              "缓解效应_非负化(%)":(g0-g_nn)/g0*100 if (g0 and g_nn) else None,
                              "负净负担城市数":int((per_net_raw<0).sum())})
df_sens = pd.DataFrame(sens_rows)

# ============================================================
# 13城净负担补充（增量口径，含源城市减负担）
# 注：本表统一用增量转移CSV口径（与9城主结果的总量口径不同，仅用于展示源-承接方向性）
# ============================================================
def source_burden(scn):
    f = BASE + (r"\情景一_增量转移_算力_能耗_热量_碳排放_总表_统一口径版.csv" if scn=="S1"
                else r"\情景二_增量转移_算力_能耗_热量_碳排放_总表_最终版.csv")
    df = pd.read_csv(f)
    rows = []
    for y in YEARS:
        dyy = df[df["年份"]==y]
        # 9承接城加负担（增量口径=该Target承接的所有Carbon emission之和）
        for c_en, c in T9.items():
            carbon_add = float(dyy[dyy["Target"]==c_en]["Carbon emission (Mt)"].sum())
            rows.append({"年份":y,"城市":c,"角色":"承接","加负担(Mt)":carbon_add,"减负担(Mt)":0,
                         "净负担(Mt)":carbon_add})
        # 源城市减负担 = Σ Energy × (Source_EF - Target_EF)
        src_red = {}
        for _, r in dyy.iterrows():
            s_en, t_en = r["Source"], r["Target"]
            energy = r["Energy (TWh)"]
            s_cn = EN2CN.get(s_en); t_cn = EN2CN.get(t_en)
            if s_cn not in C13 or t_cn not in C13: continue
            s_ef = ef_pivot.loc[y, s_cn] if s_cn in ef_pivot.columns else None
            t_ef = ef_pivot.loc[y, t_cn] if t_cn in ef_pivot.columns else None
            if s_ef is None or t_ef is None: continue
            # 1 TWh × 1 kgCO2/kWh = 1 Mt CO2
            red = energy * (s_ef - t_ef)  # 正=迁出减排（源EF高），负=迁出增排（target EF高）
            src_red[s_cn] = src_red.get(s_cn, 0) + red
        for s_cn, red in src_red.items():
            if s_cn in C9:
                for rr in rows:
                    if rr["年份"]==y and rr["城市"]==s_cn:
                        rr["减负担(Mt)"] = -red  # 减负担：正=避免排放，负=额外负担
                        rr["净负担(Mt)"] = rr["加负担(Mt)"] + rr["减负担(Mt)"]
                        break
            else:
                rows.append({"年份":y,"城市":s_cn,"角色":"源","加负担(Mt)":0,"减负担(Mt)":-red,
                             "净负担(Mt)":-red})
    return pd.DataFrame(rows)

df13_S1 = source_burden("S1")
df13_S2 = source_burden("S2")
# 加人均
for df13, scn in [(df13_S1,"S1"),(df13_S2,"S2")]:
    df13["人均净负担(tCO2/cap)"] = df13.apply(
        lambda r: r["净负担(Mt)"]*1e6/(float(pop_pred[r["城市"]][YEARS.index(r["年份"])])*1e4)
                  if r["城市"] in pop_pred else np.nan, axis=1)

# ============================================================
# 写Excel
# ============================================================
def style_hdr(ws, ncol, row=1):
    hd = PatternFill("solid", fgColor="FF1F4E78")
    ft = Font(name="微软雅黑", size=11, bold=True, color="FFFFFFFF")
    bd = Border(left=Side("thin",color="FFBFBFBF"),right=Side("thin",color="FFBFBFBF"),
                top=Side("thin",color="FFBFBFBF"),bottom=Side("thin",color="FFBFBFBF"))
    for j in range(1, ncol+1):
        c = ws.cell(row=row, column=j); c.fill=hd; c.font=ft; c.border=bd
        c.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)

def write_df(ws, df, start_row=1):
    for j, col in enumerate(df.columns, start=1):
        ws.cell(row=start_row, column=j, value=col)
    for i, (_, r) in enumerate(df.iterrows(), start=start_row+1):
        for j, col in enumerate(df.columns, start=1):
            v = r[col]
            if isinstance(v, (np.integer,)): v = int(v)
            elif isinstance(v, (np.floating,)): v = float(v) if not np.isnan(v) else None
            ws.cell(row=i, column=j, value=v)
    style_hdr(ws, len(df.columns), start_row)

wb = openpyxl.Workbook()
ws = wb.active; ws.title = "9城碳负担与人均GDP"
write_df(ws, df1)

ws = wb.create_sheet("Gini_Theil指数")
write_df(ws, df_gini)

ws = wb.create_sheet("方案敏感性")
write_df(ws, df_sens)

ws = wb.create_sheet("13城净负担_BS")
write_df(ws, df13_S1)

ws = wb.create_sheet("13城净负担_TAS")
write_df(ws, df13_S2)

# 方法说明
ws = wb.create_sheet("方法说明")
notes = [
    ["一、框架", ""],
    ["三层结构", "①碳负担分配（谁承担）：9承接城S1/S2总转移排放的人均/单位GDP分布；②余热收益分配（谁受益）：方案1/2/3三路径（供暖/制冷/供电）减排量；③缓解效应：有余热vs无余热的Gini下降%。"],
    ["情景", "BS=S1基准情景；TAS=S2算力转移情景。"],
    ["余热方案", "方案1低回收率、方案2中、方案3高（主结果用方案2，敏感性给1/3）。"],
    ["分组", "煤电高EF组（呼和浩特/张家口/芜湖/庆阳/中卫，2026年EF≥0.4）；清洁低EF组（成都/重庆/贵阳/韶关，EF<0.4）。对应论文'煤电电网vs清洁电网'。"],
    ["", ""],
    ["二、指数", ""],
    ["Gini系数", "人口加权Gini公式 G=(2/μ)·Σw_i·(x_i−μ)·(R_i−0.5)，w_i=人口份额，R_i=累计人口份额到中点(Σ_{j≤i}w_j−w_i/2)，μ=加权均值。xi按升序排列。与07_DCEA.c_weighted同口径（排序按x本身时C=Gini），与06 Fig2 Lorenz曲线（横轴累计人口份额）同口径。可处理负值，要求μ≠0。"],
    ["双口径报告", "原始口径：净负担含负值（成都/重庆等低负担城市余热减排>碳负担时为负），Gini可能>1；非负化口径：max(净负担,0)，负值城市记为0，Gini∈[0,1]。两口径并列报告，分离机制A（高负担城市缓解不足，真实效应）与机制B（低负担城市会计负值，指标假象）。"],
    ["Theil T", "人口加权Theil T=Σw_i·(x_i/μ)·ln(x_i/μ)，μ=加权均值。仅对全正序列严格定义；含负值时用加权相对均值绝对偏差作稳健替代。"],
    ["组间/组内分解", "人口加权Theil_T = T_between(煤电vs清洁组间差异) + T_within(组内差异)。T_between=Σ_g W_g·(μ_g/μ)·ln(μ_g/μ)，W_g=组人口份额，μ_g=组加权均值。组间贡献率=T_between/T_total。"],
    ["缓解效应", "(Gini_无余热 - Gini_有余热)/Gini_无余热 × 100%。正值=余热降低不平等；负值=余热加剧不平等。非负化口径下的缓解效应反映'高负担城市缓解不足'的真实结构效应。"],
    ["", ""],
    ["三、分母", ""],
    ["人口/GDP来源", "《13城市人口GDP预测_2005-2035》中情景GDP（增速收敛法，g∞=2.5%）；人口为von Bertalanffy拟合。"],
    ["人均碳负担", "tCO2/capita = 碳负担(Mt)×1e6 / (人口(万人)×1e4)。"],
    ["单位GDP碳负担", "tCO2/万元 = 碳负担(Mt)×1e6 / (GDP(亿元)×1e4)。"],
    ["", ""],
    ["四、13城净负担补充", ""],
    ["源城市减负担", "= Σ_target Energy(TWh) × (Source_EF − Target_EF)。物理含义：算力若留在源城市（用源EF）会比迁到Target（用Target EF）多排放的部分，即源城市'避免的排放'（负值）。1 TWh×1 kgCO2/kWh = 1 Mt CO2。"],
    ["双重城市", "成都/重庆/张家口/芜湖/韶关既是Source又是Target，净负担=加负担(承接)+减负担(转出)。"],
    ["注", "13城补充表统一用增量转移CSV口径（与9城主结果的总量口径不同，仅用于展示源-承接方向性与源城市角色）。源城市EF来自修正后的13城市因子表（北京/上海/广东=中位值，9承接=高速发展情景下限值，情景口径差异在SI注明）。"],
    ["", ""],
    ["五、关于缓解效应为负的机制分解（核心方法学说明）", ""],
    ["机制A(真实效应)", "高负担城市（呼和浩特/中卫/庆阳）负担基数大，余热仅抵消30-76%，净负担仍为正且高。非负化口径下缓解效应为微弱负（约-1%至-4%），反映'余热回收不足'的真实结构问题——这是有力的政策信号。"],
    ["机制B(会计假象)", "低负担城市（成都/重庆/韶关）余热减排在核算上超过迁移附加碳，净负担变负。原始口径下这些负值把Gini从0.74推至>1，贡献了大幅负缓解效应（-37%等）。这不是真实的不公平恶化，而是指标被负值污染。"],
    ["双口径报告", "非负化口径隔离机制A（真实），原始口径保留机制B（会计）。两种口径都指向同一结论：单纯余热回收不能缓解不平等。"],
    ["政策落点", "要真正缓解，必须靠跨区域补偿（将高负担城市的余热收益部分转移给受影响城市），而非依赖低负担城市的会计负值。"],
    ["稳健性", "主结果以人口加权Gini_人均碳负担（全正，0.90-0.91）为锚；非负化净负担Gini（0.92-0.94）作为机制A的真实效应指标；人口加权Theil组间贡献率（51-60%，煤电vs清洁电网组间差异是不平等主因）作为结构性指标。所有指标与07_DCEA C指数、10_robust CV/RMD/Atkinson同口径（人口加权），三层框架闭合。"],
    ["会计边界声明", "净负担为负表示'核算上余热减排超过迁移附加碳'，不等于该城市物理上负排放。论文须明确此会计边界。"],
]
for r in notes:
    ws.append(r)
ws.column_dimensions["A"].width = 24; ws.column_dimensions["B"].width = 95

wb.save(OUT)
print(f"✓ 碳不平等测算结果已写入: {OUT}")

# 打印关键结果
print("== 关键Gini结果（TAS情景，方案2余热，双口径）==")
for y in [2026, 2030, 2035]:
    r = df_gini[(df_gini["情景"]=="TAS算力转移")&(df_gini["年份"]==y)]
    if len(r):
        r = r.iloc[0]
        print(f"  {y}: Gini_碳负担={r['Gini_人均碳负担(无余热)']:.4f}")
        print(f"       原始:  Gini_净负担={r['Gini_人均净负担_原始(方案2)']:.4f} | 缓解={r['缓解效应_原始(%)']:+.2f}%")
        print(f"       非负化:Gini_净负担={r['Gini_人均净负担_非负化(方案2)']:.4f} | 缓解={r['缓解效应_非负化(%)']:+.2f}%")
        print(f"       Theil={r['Theil_人均碳负担']:.4f}(组间{r['Theil_组间(煤电vs清洁)']:.4f},贡献{r['组间贡献率(%)']:.1f}%)")
print("\n== 方案敏感性（TAS 2035，三方案×双口径）==")
sub = df_sens[(df_sens["情景"]=="TAS算力转移")&(df_sens["年份"]==2035)]
for _, r in sub.iterrows():
    print(f"  {r['余热方案']}: 原始Gini={r['Gini_人均净负担_原始']:.4f}(缓解{r['缓解效应_原始(%)']:+.2f}%) | 非负化Gini={r['Gini_人均净负担_非负化']:.4f}(缓解{r['缓解效应_非负化(%)']:+.2f}%) | 负净负担城市{r['负净负担城市数']}个")
print("\n== 13城净负担2035（TAS）==")
sub = df13_S2[df13_S2["年份"]==2035].sort_values("净负担(Mt)")
print(sub[["城市","角色","加负担(Mt)","减负担(Mt)","净负担(Mt)","人均净负担(tCO2/cap)"]].to_string(index=False))
